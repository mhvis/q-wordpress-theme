<?php
/**
 * Footer Style 3 File
 *
 * @since  1.0
 */
?>
<div id="site-footer-widgets" class="footer-style-3 site-footer-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div id="footer-style-3-text">
					<p class="dunhakdis-headings">
						<?php flocks_site_logo( 'site-logo-img-footer' ); ?>
					</p>
					<p>
						<?php esc_html_e("Flocks is the most innovative &amp; complete social networking theme for WordPress &amp; BuddyPress. It's worth a buck. Create website easily. Spend more of your time planning your business. Having a good WordPress theme can save you a lot of troubles.", 'flocks'); ?>
					</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div id="footer-style-3-social-media">
				<?php $flocks_top_social = get_theme_mod('flocks_top_social'); ?>

					<ul id="footer-style-3-social-media-list">

						<?php if ( empty( $flocks_top_social ) ) { ?>

							<li class="item">
								<a title="<?php esc_html_e('Dribbble', 'flocks'); ?>" href="#"><i class="fa fa-dribbble"></i></a>
							</li>
							<li class="item">
								<a title="<?php esc_html_e('Google Plus', 'flocks'); ?>" href="#"><i class="fa fa-google-plus"></i></a>
							</li>
							<li class="item">
								<a title="<?php esc_html_e('Twitter', 'flocks'); ?>" href="#"><i class="fa fa-twitter"></i></a></li>
							<li class="item">
								<a title="<?php esc_html_e('Facebook', 'flocks'); ?>" href="#"><i class="fa fa-facebook"></i></a>
							</li>

						<?php } else { ?>

						<?php foreach( $flocks_top_social as $social_item ): ?>
							<li class="item">
								<a href="<?php echo esc_url( $social_item['link_url'] );?>" title="<?php echo esc_attr( $social_item['link_icon'] );?>">
									<i class="fa fa-<?php echo esc_attr( $social_item['link_icon'] );?>"></i>
								</a>
							</li>
						<?php endforeach; ?>
						
						<?php } ?>

					</ul>
				</div>
			</div>
		</div>
	</div>
</div>