<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Create new Customizer Section called 'Content Header'
 */
Flocks_Kirki::add_section( 'flocks_content_header', array(
    'title'          => esc_html__( 'Content Header', 'flocks' ),
    'description'    => esc_html__( 'Content Header is the section where the page or post title is located. You can overwrite the option below for each Post or Page.', 'flocks' ),
    'priority'       => 10,
) );


/**
 * Default Background Image
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'image',
	'settings'    => 'flocks_content_header_image',
	'label'       => esc_html__( 'Default Background Image', 'flocks' ),
	'default'	  => sprintf( '%s/assets/images/default-cover-image.jpg', get_template_directory_uri() ),
	'description' => esc_html__( 'Upload an image or enter an URL. 1200 x 300 (4:1 Aspect Ratio)', 'flocks' ),
	'section'     => 'flocks_content_header',
	'priority'    => 10,
) );

/**
 * Default Optional Sub Header
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'textarea',
	'settings' => 'flocks_content_header_sub_heading',
	'label'    => esc_html__( 'Default Sub Heading Title', 'flocks' ),
	'description'  => esc_html__( 'Populate the textarea to add a subheading text under the page title', 'flocks' ),
	'section'  => 'flocks_content_header',
	'priority' => 10,
) );

/**
 * Text Color
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_content_header_color',
	'label'       => esc_html__( 'Default Text Color', 'flocks' ),
	'description'  => esc_html__( 'Use the tool below to select a Text Color', 'flocks' ),
	'section'     => 'flocks_content_header',
	'default'     => '#fff',
	'priority'    => 10,
	'choices'     => array(
		'alpha' => true,
	),
) );

/**
 * Background Color
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_content_background_color',
	'label'       => esc_html__( 'Default Background Color', 'flocks' ),
	'description'  => esc_html__( 'Use the tool below to select a Background Color', 'flocks' ),
	'section'     => 'flocks_content_header',
	'default'     => '#171715',
	'priority'    => 10,
	'choices'     => array(
		'alpha' => true,
	),
) );

/**
 * Heading Size
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_content_background_heading_size',
	'label'       => esc_html__( 'Default Heading Size', 'flocks' ),
	'section'     => 'flocks_content_header',
	'default'     => 'standard',
	'priority'    => 10,
	'choices'     => array(
		'small'   => esc_attr__( 'Small', 'flocks' ),
		'standard'   => esc_attr__( 'Standard (default)', 'flocks' ),
		'bigger' => esc_attr__( 'Bigger', 'flocks' ),
		'extra-large'  => esc_attr__( 'Extra Large', 'flocks' ),
	),
) );

/**
 * Heading Alignment
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_content_background_heading_alignment',
	'label'       => esc_html__( 'Default Heading Size', 'flocks' ),
	'section'     => 'flocks_content_header',
	'default'     => 'align-center',
	'priority'    => 10,
	'choices'     => array(
		'align-left'   => esc_attr__( 'Align Left', 'flocks' ),
		'align-center'   => esc_attr__( 'Centered (default)', 'flocks' ),
		'align-right' => esc_attr__( 'Align Right', 'flocks' ),
	),
) );