<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *  Footer Section
 */
Flocks_Kirki::add_section( 'flocks_footer', array(
    'title'          => esc_attr__( 'Footer Section', 'flocks' ),
    'description'    => esc_attr__( 'All customizations related to Flocks Headline.', 'flocks' ),
    'panel'          => '', // Not typically needed.
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '', // Rarely needed.
) );

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_footer_style',
	'label'       => esc_html__( 'Footer Style', 'flocks' ),
	'section'     => 'flocks_footer',
	'default'     => 'style-1',
	'priority'    => 10,
	'choices'     => array(
		'footer-style-1'  => esc_attr__('Footer Style 1', 'flocks'),
		'footer-style-2'  => esc_attr__('Footer Style 2', 'flocks'),
		'footer-style-3'  => esc_attr__('Footer Style 3', 'flocks')
	),
) );

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'image',
	'settings'    => 'image_demo',
	'label'       => esc_attr__( 'Background Image', 'flocks' ),
	'description' => esc_attr__( 'Upload a background image for the site footer.', 'flocks' ),
	'section'     => 'flocks_footer',
	'default'     => esc_url( get_template_directory_uri() . '/assets/images/footer-bg.jpg' ),
	'priority'    => 10,
	'transport'   => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#site-footer-widgets.footer-style-3, #site-footer-widgets.footer-style-2',
			'function' => 'css',
			'property' => 'background-image'
		),
	),
	'output' => array(
		array(
			'element'  => '#site-footer-widgets.footer-style-3, #site-footer-widgets.footer-style-2',
			'function' => 'css',
			'property' => 'background-image',
			'value_pattern' => 'url($)'
		),
	),
	'active_callback' => array(
    	array(
    		'setting'  => 'flocks_footer_style',
    		'operator' => 'in',
    		'value'    => array( 'footer-style-2', 'footer-style-3' )
    	)
    )
) );
?>