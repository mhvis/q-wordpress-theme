<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 *  Footer Call to Action
 */
Flocks_Kirki::add_section( 'flocks_footer_cta', array(
    'title'          => esc_html__( 'Footer CTA', 'flocks' ),
    'description'    => esc_html__( 'All customizations related to Flocks CTA.', 'flocks' ),
    'panel'          => '', // Not typically needed.
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '', // Rarely needed.
) );

/**
 * Footer CTA Headline Title
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'textarea',
	'settings' => 'flocks_footer_cta_title',
	'label'    => esc_html__( 'Headline Title', 'flocks' ),
	'section'  => 'flocks_footer_cta',
	'default'  => esc_attr__( 'Get Started with WordPress & BuddyPress', 'flocks' ),
	'priority' => 10,
	'transport' => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action .call-to-action-heading',
			'function' => 'html',
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-call-to-action .call-to-action-heading',
			'function' => 'html',
		),
	)
) );

/**
 * Footer CTA Subheading
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'textarea',
	'settings' => 'flocks_footer_cta_subheading',
	'label'    => esc_html__( 'Subheading', 'flocks' ),
	'section'  => 'flocks_footer_cta',
	'default'  => esc_attr__( 'Over 60 million people have chosen WordPress to power the place on the web they call "home" - Join the family.', 'flocks' ),
	'priority' => 10,
	'transport' => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action .call-to-action-excerpt',
			'function' => 'html',
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-call-to-action .call-to-action-excerpt',
			'function' => 'html',
		),
	)
) );

/**
 * Footer CTA Button Text
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'text',
	'settings' => 'flocks_footer_cta_btn_text',
	'label'    => esc_html__( 'Button Text', 'flocks' ),
	'section'  => 'flocks_footer_cta',
	'default'  => esc_attr__( 'Get Started', 'flocks' ),
	'priority' => 10,
	'transport' => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#call-to-action-button',
			'function' => 'html',
		),
	)
) );

/**
 * Footer CTA Button Link
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'text',
	'settings' => 'flocks_footer_cta_btn_link',
	'label'    => esc_html__( 'Button Link', 'flocks' ),
	'section'  => 'flocks_footer_cta',
	'default'  => esc_attr__( '#', 'flocks' ),
	'priority' => 10
) );


/**
 * Footer CTA Button Link (Open new tab?)
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'checkbox',
	'settings'    => 'flocks_footer_cta_btn_new_tab',
	'label'       => esc_html__( 'Open in new tab?', 'flocks' ),
	'section'     => 'flocks_footer_cta',
	'default'     => '1',
	'priority'    => 10,
) );

/**
 * Footer CTA  Heading Color
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_footer_cta_heading_color',
	'label'       => esc_html__( 'Heading Color', 'flocks' ),
	'section'     => 'flocks_footer_cta',
	'default'     => '#555555',
	'priority'    => 10,
	'transport'   => 'postMessage',
	'alpha'       => false,
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action .call-to-action-heading',
			'function' => 'css',
			'property' => 'color'
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-call-to-action .call-to-action-heading',
			'function' => 'css',
			'property' => 'color'
		),
	)

) );

/**
 * Footer CTA Sub Heading Color
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_footer_cta_sub_heading_color',
	'label'       => esc_html__( 'Sub Heading Color', 'flocks' ),
	'section'     => 'flocks_footer_cta',
	'default'     => '#9b9b9b',
	'priority'    => 10,
	'alpha'       => false,
	'transport'   => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action .call-to-action-excerpt',
			'function' => 'css',
			'property' => 'color'
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-call-to-action .call-to-action-excerpt',
			'function' => 'css',
			'property' => 'color'
		),
	)
) );

/**
 * Footer CTA Button Color
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_footer_cta_btn_color',
	'label'       => esc_html__( 'Button Color', 'flocks' ),
	'section'     => 'flocks_footer_cta',
	'default'     => flocks_get_primary_color(),
	'priority'    => 10,
	'alpha'       => false,
	'transport'   => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action #call-to-action-button',
			'function' => 'css',
			'property' => 'background'
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-call-to-action #call-to-action-button',
			'function' => 'css',
			'property' => 'background'
		),
	)
) );

/**
 * Footer CTA Button Color
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_footer_cta_bg_color',
	'label'       => esc_html__( 'Section Background Color', 'flocks' ),
	'section'     => 'flocks_footer_cta',
	'default'     => '#fff',
	'priority'    => 10,
	'alpha'       => false,
	'transport'   => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action',
			'function' => 'css',
			'property' => 'background'
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-call-to-action',
			'function' => 'css',
			'property' => 'background'
		),
	)
) );

/**
 * Footer CTA Enable/Disable
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_footer_cta_enabled',
	'label'       => esc_html__( 'Disable Footer CTA', 'flocks' ),
	'section'     => 'flocks_footer_cta',
	'default'     => 'none',
	'transport'   => 'postMessage',
	'priority'    => 10,
	'choices'     => array(
		'none' => esc_attr__( 'Disable', 'flocks' ),
		'block'  => esc_attr__( 'Enable', 'flocks' ),
	),
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action',
			'function' => 'css',
			'property' => 'display',
		),
	)
) );
?>