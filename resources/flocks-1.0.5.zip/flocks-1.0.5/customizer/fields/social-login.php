<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Flocks_Kirki::add_section( 'flocks_social_login', array(
    'title'          => esc_attr__( 'Social Login', 'flocks' ),
    'description'    => esc_attr__( 'All customizations related to Social Logins. <strong>Social Login requires PHP 5.4+ version with PHP Curl enabled</strong>.', 'flocks' ),
    'panel'          => '', // Not typically needed.
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '', // Rarely needed.
) );

// FB Connect (enable/disable)
Flocks_Kirki::add_field( 'enable_facebook_connect', array(
	'type'        => 'select',
	'settings'    => 'enable_facebook_connect',
	'label'       => esc_attr__( 'Enable Facebook Connect', 'flocks' ),
	'section'     => 'flocks_social_login',
	'description' => esc_attr__('Toggle to disable or enable user login using Facebook Account. You need to create a new Facebook App and then enter the App ID and App Secret in the associated fields below. ', 'flocks'),
	'default'     => 'disable',
	'priority'    => 10,
	'choices'     => array(
		'enable'  => esc_attr__( 'Enabled', 'flocks' ),
		'disable' => esc_attr__( 'Disabled', 'flocks' ),
	),
) );

// FB Api ID
Flocks_Kirki::add_field( 'facebook_api_id', array(
	'type'     => 'text',
	'settings' => 'facebook_api_id',
	'label'    => esc_attr__( 'Facebook App ID', 'flocks' ),
	'description' => sprintf( esc_attr__( 'Click %s to learn on how to get your FB App ID.', 'flocks'), '<a href="#" target="__blank"><u>here</u></a>' ),
	'section'  => 'flocks_social_login',
	'default'  => esc_attr__( '40121904-(Get Your Own)', 'flocks' ),
	'priority' => 10,
	'active_callback'  => array(
		array(
			'setting'  => 'enable_facebook_connect',
			'operator' => '==',
			'value'    => 'enable',
			)
		),
) );

// FB Api Secret
Flocks_Kirki::add_field( 'facebook_api_secret', array(
	'type'     => 'text',
	'settings' => 'facebook_api_secret',
	'label'    => esc_attr__( 'Facebook App Secret', 'flocks' ),
	'description' => sprintf( esc_attr__( 'Click %s to learn on how to get your FB Secret.', 'flocks'), '<a href="#" target="__blank"><u>here</u></a>' ),
	'section'  => 'flocks_social_login',
	'default'  => esc_attr__( '6911f0e323b-(Get Your Own)', 'flocks' ),
	'priority' => 10,
	'active_callback'  => array(
		array(
			'setting'  => 'enable_facebook_connect',
			'operator' => '==',
			'value'    => 'enable',
			)
		),
) );

// FB Button Label
Flocks_Kirki::add_field( 'facebook_api_button_name', array(
	'type'     => 'text',
	'settings' => 'facebook_api_button_name',
	'label'    => esc_attr__( 'Facebook Button Label', 'flocks' ),
	'section'  => 'flocks_social_login',
	'default'  => esc_attr__( 'Facebook Connect', 'flocks' ),
	'priority' => 10,
	'active_callback'  => array(
		array(
			'setting'  => 'enable_facebook_connect',
			'operator' => '==',
			'value'    => 'enable',
			)
		),
) );


/**
 * Google Connect
 */
// Google Connect (enable/disable)
Flocks_Kirki::add_field( 'enable_google_connect', array(
	'type'        => 'select',
	'settings'    => 'enable_google_connect',
	'label'       => esc_attr__( 'Enable Google Connect', 'flocks' ),
	'description' => esc_attr__('Toggle to disable or enable user login using Google Account. You need to create a new Google App and then enter the 
	Client ID and the Client Secret in the associated fields below. ', 'flocks'),
	'section'     => 'flocks_social_login',
	'default'     => 'disable',
	'priority'    => 10,
	'choices'     => array(
		'enable'  => esc_attr__( 'Enabled', 'flocks' ),
		'disable' => esc_attr__( 'Disabled', 'flocks' ),
	),
) );

// Google Api ID
Flocks_Kirki::add_field( 'google_api_id', array(
	'type'     => 'text',
	'settings' => 'google_api_id',
	'label'    => esc_attr__( 'Google Client ID', 'flocks' ),
	'section'  => 'flocks_social_login',
	'description' => sprintf( esc_attr__( '%s to learn on how to get your Google Client ID.', 'flocks'), '<a href="#" target="__blank"><u>Click here</u></a>' ),
	'default'  => esc_attr__( '1029578692451-(Get Your Own)', 'flocks' ),
	'priority' => 10,
	'active_callback'  => array(
		array(
			'setting'  => 'enable_google_connect',
			'operator' => '==',
			'value'    => 'enable',
			)
		),
) );

// Google Api Secret
Flocks_Kirki::add_field( 'google_api_secret', array(
	'type'     => 'text',
	'settings' => 'google_api_secret',
	'label'    => esc_attr__( 'Google Client Secret', 'flocks' ),
	'description' => sprintf( esc_attr__( '%s to learn on how to get your Google Client Secret.', 'flocks'), '<a href="#" target="__blank"><u>Click here</u></a>' ),
	'section'  => 'flocks_social_login',
	'default'  => esc_attr__( 'zWHSTEQvTwU-(Get Your Own)', 'flocks' ),
	'priority' => 10,
	'active_callback'  => array(
		array(
			'setting'  => 'enable_google_connect',
			'operator' => '==',
			'value'    => 'enable',
			)
		),
) );

// Google Button Label
Flocks_Kirki::add_field( 'google_api_button_name', array(
	'type'     => 'text',
	'settings' => 'google_api_button_name',
	'label'    => esc_attr__( 'Google Button Label', 'flocks' ),
	'section'  => 'flocks_social_login',
	'default'  => esc_attr__( 'GOOGLE CONNECT', 'flocks' ),
	'priority' => 10,
	'active_callback'  => array(
		array(
			'setting'  => 'enable_google_connect',
			'operator' => '==',
			'value'    => 'enable',
			)
		),
) );

Flocks_Kirki::add_field( 'google_api_redirect_instruction', array(
	'type'        => 'custom',
	'settings'    => 'google_api_redirect_instruction',
	'description' => esc_attr__('Important: Add the following URL in your Google Developer Console "Authorized redirect URIs"', 'flocks'),
	'label'       => esc_attr__( 'Authorized redirect URIs', 'flocks' ),
	'section'     => 'flocks_social_login',
	'default'     => '<div style="padding: 15px;background-color: #f6f8f9; color: #777; border-color: #eee;border-radius: 4px;">' 
					. admin_url( "admin-ajax.php?action=clientConnectionInit" ) . '</div>',
	'priority'    => 10,
	'active_callback'  => array(
		array(
			'setting'  => 'enable_google_connect',
			'operator' => '==',
			'value'    => 'enable',
			)
		),
) );