<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 *  Footer Headline Section
 */
Flocks_Kirki::add_section( 'flocks_footer_headline', array(
    'title'          => esc_attr__( 'Footer Headline', 'flocks' ),
    'description'    => esc_attr__( 'All customizations related to Flocks Headline.', 'flocks' ),
    'panel'          => '', // Not typically needed.
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '', // Rarely needed.
) );

/**
 * Footer Headline Background
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'image',
	'settings'    => 'flocks_footer_headline_bg',
	'label'       => esc_attr__( 'Background Image', 'flocks' ),
	'description' => esc_attr__( 'Use the button below to upload an image that will be use as the background of this section.', 'flocks' ),
	'section'     => 'flocks_footer_headline',
	'default'     => trailingslashit( get_template_directory_uri() ). 'assets/images/call-to-action-before.jpg',
	'priority'    => 10,
	'transport'	  => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-before-to-action',
			'function' => 'css',
			'property' => 'background-image'
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-before-to-action',
			'function' => 'css',
			'property' => 'background-image',
			'value_pattern' => 'url($)'
		),
	)
) );

/**
 * Footer Headline Title
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'textarea',
	'settings' => 'flocks_footer_headline_title',
	'label'    => esc_attr__( 'Headline Title', 'flocks' ),
	'section'  => 'flocks_footer_headline',
	'default'  => esc_attr__( 'Welcome to Flocks Community WordPress Theme', 'flocks' ),
	'priority' => 10,
	'transport' => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action-head',
			'function' => 'html',
		),
	)
) );

/**
 * Footer Headline TextArea
 */
$footer_headline_textarea = esc_attr__( 'This is a <em>Footer Headline</em> section that you can use to display any information you like. You can change this text inside the theme\'s live customizer. This section can show HTML and all of your favorite shortcodes. You can also replace the background image, the background color, the title, and the opacity. Kind of cool, right?
', 'flocks' );

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'textarea',
	'settings' => 'flocks_footer_headline_textarea',
	'label'    => esc_attr__( 'Headline Content', 'flocks' ),
	'transport' => 'postMessage',
	'section'  => 'flocks_footer_headline',
	'default'  => ( $footer_headline_textarea ),
	'priority' => 10,
	'js_vars' => array(
		array(
			'element'  => '#footer-call-to-action-text',
			'function' => 'html',
		),
	)
) );


/**
 * Footer Headline Background Color
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_footer_headline_bg_color',
	'label'       => esc_attr__( 'Background Color', 'flocks' ),
	'section'     => 'flocks_footer_headline',
	'default'     => flocks_get_primary_color(),
	'priority'    => 10,
	'transport'   => 'postMessage',
	'alpha'       => false,
	'js_vars' => array(
		array(
			'element'  => '#footer-before-to-action:before',
			'function' => 'css',
			'property' => 'background-color'
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-before-to-action:before',
			'function' => 'css',
			'property' => 'background-color',
		),
	)
) );

/**
 * Footer Headline Color
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_footer_headline_color',
	'label'       => esc_attr__( 'Foreground Color', 'flocks' ),
	'section'     => 'flocks_footer_headline',
	'default'     => '#ffffff',
	'priority'    => 10,
	'transport'   => 'postMessage',
	'alpha'       => false,
	'js_vars' => array(
		array(
			'element'  => '#footer-before-to-action, h3.call-to-action-heading',
			'function' => 'css',
			'property' => 'color'
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-before-to-action, h3.call-to-action-heading',
			'function' => 'css',
			'property' => 'color',
		),
	)
) );

/**
 * Footer Headline Opacity
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'slider',
	'settings'    => 'flocks_footer_headline_opacity',
	'label'       => esc_attr__( 'Opacity', 'flocks' ),
	'section'     => 'flocks_footer_headline',
	'default'     => 80,
	'transport'   => 'postMessage',
	'choices'     => array(
		'min'  => '0',
		'max'  => '99',
		'step' => '1',
	),
	'js_vars' => array(
		array(
			'element'  => '#footer-before-to-action:before',
			'function' => 'css',
			'property' => 'opacity',
			'prefix' => '0.',
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-before-to-action:before',
			'function' => 'css',
			'property' => 'opacity',
			'prefix' => '0.',
		),
	)
) );

/**
 * Footer Headline Enable/Disable
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_footer_headline_enabled',
	'label'       => esc_attr__( 'Disable Footer Headline', 'flocks' ),
	'section'     => 'flocks_footer_headline',
	'default'     => 'none',
	'transport'   => 'postMessage',
	'priority'    => 10,
	'choices'     => array(
		'none' => esc_attr__( 'Disable', 'flocks' ),
		'block'  => esc_attr__( 'Enable', 'flocks' ),
	),
	'js_vars' => array(
		array(
			'element'  => '#footer-before-to-action',
			'function' => 'css',
			'property' => 'display',
		),
	)
) );
?>