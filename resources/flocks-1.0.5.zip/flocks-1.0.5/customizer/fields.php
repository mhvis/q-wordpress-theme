<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Defining our Kirki Custom Config
 */
Flocks_Kirki::add_config( 
	'flocks_customizer_config', 
	array(
    	'capability'    => 'edit_theme_options',
    	'option_type'   => 'theme_mod',
	)
);

$customizer_sections = array( 
	'site-layout', 
	'header', 
	'site-logo', 
	'typography', 
	'content-header', 
	'single-blog', 
	'sign-in-page', 
	'social-login',
	'footer-section', 
	'footer-headline', 
	'footer-cta',
);

foreach ( $customizer_sections as $section ):
	
	$customizer_section_file = get_template_directory() . sprintf( '/customizer/fields/%s.php', sanitize_title( $section ) );
	
	if ( file_exists( $customizer_section_file ) ):
		
		require_once $customizer_section_file;

	endif;

endforeach;
?>
