<?php
/**
 * The sidebar containing the main widget area.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Flocks
 */
 $sidebar 		= 'sidebar-1';
 $sidebar_right = 'sidebar-1';
 $sidebar_left 	= 'sidebar-1';
 $page_layout   = 'content-sidebar';
 $is_shop 		= false;

 $object_id = get_queried_object_id();

 if ( function_exists('is_shop') ) {
 	if ( is_shop() ) {
 		$object_id = get_option( 'woocommerce_shop_page_id' );
 		$is_shop = true;
 	}
 }

 if ( is_archive() ) {
 	if ( ! $is_shop ) {
 		$sidebar = 'archives';
 	}
}


if ( function_exists('is_woocommerce') ) {

    if ( is_woocommerce() ) {
        $sidebar = 'shop-page';
    }

    if ( is_shop() ) {
        $sidebar = 'shop-page';
    }
}

if ( function_exists('is_bbpress') ) {

	if ( is_bbpress() ) {
		$sidebar = 'forums';
	}
}


if ( ! empty( $object_id ) ) {

	$sidebar_right = get_post_meta( $object_id, 'flocks_sidebar', true );
	$sidebar_left  = get_post_meta( $object_id, 'flocks_sidebar_left', true );
	$page_layout   = get_post_meta( $object_id, 'flocks_page_layout', true );

	if ( 'sidebar-content' === $page_layout ) {
		$sidebar = $sidebar_left;
	}

	if ( 'content-sidebar' === $page_layout ) {
		$sidebar = $sidebar_right;
	}

}

?>

 <div id="secondary" class="widget-area">

 	<?php if ( is_active_sidebar( $sidebar ) ) { ?>

 		<?php dynamic_sidebar( esc_attr( $sidebar ) ); ?>

 	<?php } ?>

 </div><!-- #secondary -->
