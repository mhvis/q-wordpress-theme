<?php

/**
 * Search 
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<form class="form-inline" method="get" id="bbp-search-form" action="<?php bbp_search_url(); ?>">
	<div class="row">
		<div class="col-md-10">
			<label class="screen-reader-text hide" for="bbp_search">
				<?php esc_html_e( 'Search for:', 'flocks' ); ?>
			</label>
			<input type="hidden" name="action" value="bbp-search-request" />
			<input placeholder="<?php esc_attr_e('Search forums, topics, and replies ', 'flocks'); ?>" type="text" value="<?php echo esc_attr( bbp_get_search_terms() ); ?>" name="bbp_search" id="bbp_search" />
		</div>
		<div class="col-md-2">
			<input type="submit" value="<?php esc_attr_e('Search', 'flocks'); ?>" class="flocks-bbp-search-btn" />
		</div>
	</div>
</form>