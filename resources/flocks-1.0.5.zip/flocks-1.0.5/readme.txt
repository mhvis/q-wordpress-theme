=== Flocks ===

Contributors: dunhakdis
Tags: translation-ready, custom-background, theme-options, custom-menu, post-formats, threaded-comments

Requires at least: 4.0
Tested up to: 4.7
Stable tag: 1.0.0
License: Split License
License URI: https://themeforest.net/licenses

FLOCKS - Multi-Niche Social Networking WordPress Theme

== Description ==

FLOCKS is a social networking ready WordPress theme capable of handling any niche or purpose. The theme is insanely responsive, which means it automatically adapts to any screen resolution including but not limited to Mobile Phones, Tablets, and Desktops. 

FLOCKS is for Web Developers, and Site Owners who want to leverage WordPress to power their websites. You can use Flocks to build Social Network, Community Forums, or Corporate Websites. FLOCKS is also compatible with WooCommerce plug-in allowing you to sell anything online.

With an enormous amount of effort and dedication, our team was able to produce a BuddyPress ready theme that enjoys a close attention to every detail just like our Klein, and Thrive.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

Flocks includes support for Jetpack's Infinite Scroll and Site Logos, as well as other features.

== Changelog ==

= 1.0 - May 12 2015 =
* Initial release

== Credits ==

* Based on Flocks http://components.underscores.me/, (C) 2015-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
