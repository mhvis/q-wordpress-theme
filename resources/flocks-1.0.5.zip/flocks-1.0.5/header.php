<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Flocks
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<?php wp_head(); ?>
</head>

<?php $flocks_header_style = flocks_get_header_style(); ?>

<body <?php body_class(); ?>>

<div id="global-container" class="flocks-wordpress-theme">

<div id="viewport-not-supported">
	<?php esc_html_e('Unsupported Screen Size: The viewport size is too small for the theme to render properly.', 'flocks'); ?>
</div>

<div id="header-section" class="site">

	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'flocks' ); ?></a>

	<?php get_template_part( $flocks_header_style ); ?>

</div>

<div id="content" class="site-content">
