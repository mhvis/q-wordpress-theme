<?php
/**
 * Enqueue Google Font the right way.
 */
function flocks_google_fonts_url() {

    $fonts_url = '';

    /* Translators: If there are characters in your language that are not
     * supported by Source Sans Pro, translate this to 'off'. Do not translate
     * into your own language.
     */
    $source_sans_pro = _x( 'on', 'Source Sans Pro font: on or off', 'flocks' );

    /* Translators: If there are characters in your language that are not
     * supported by Popins, translate this to 'off'. Do not translate
     * into your own language.
     */
    $popins = _x( 'on', 'Popins font: on or off', 'flocks' );

    if ( 'off' !== $source_sans_pro || 'off' !== $popins ) {

        $font_families = array();

        if ( 'off' !== $source_sans_pro ) {
            $font_families[] = 'Source Sans Pro:400,600,400italic';
        }

        if ( 'off' !== $popins ) {
            $font_families[] = 'Poppins:400,600';
        }
    }

    $query_args = array(
        'family' => urlencode( implode( '%7C', $font_families ) ),
        'subset' => urlencode( 'latin,latin-ext' ),
    );

    $fonts_url = add_query_arg( $query_args, 'https://fonts.googleapis.com/css' );

    return esc_url_raw( $fonts_url );
}

/**
 * Enqueue our newly created link to google font.
 */
add_action( 'wp_enqueue_scripts', 'flocks_google_font_styles' );

function flocks_google_font_styles() {

    wp_enqueue_style( 'flocks-google-fonts', flocks_google_fonts_url(), array(), null );

}


/**
 * Displays user info in loop
 */
if ( ! function_exists( 'flocks_author' ) ) {

	function flocks_author() {

		global $post;
		?>
    	<div class="author-about">
    		<div class="author-about-image">
    			<?php if ( function_exists( 'bp_core_fetch_avatar' ) ) { ?>
    				<?php echo bp_core_fetch_avatar( array( 'type' => 'full', 'item_id' => $post->post_author ) ); ?>
    			<?php } else { ?>
    				<div class="blog-author-avatar no-bp"><?php echo get_avatar( $post->post_author, 100 ); ?></div>
    			<?php } ?>
    		</div>
    		<div class="author-about-context">
    			
    				<div class="author vcard mg-bottom-10">
                        <h3 class="font-paragraph">
        					<a class="url fn" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>">
        						<?php the_author_meta( 'display_name' ); ?>
        					</a>
                        </h3>
                        <h3 class="font-paragraph">
                            <span class="author-expertise"><?php esc_attr_e('BuddyPress Expert', 'flocks' ); ?></span>
                        </h3>
    				</div>

                <div id="author-about-separator"></div>

    			<p>
                    <?php echo nl2br(get_the_author_meta( 'description', $post->author_id )); ?>
                </p>

    		</div>
    	</div>
	<?php
	}
}

/**
 * Social link
 */
 function flocks_social_link() {

     global $post;
    ?>
        <div class="entry-share">
            <span><?php esc_attr_e('SHARE', 'flocks' ); ?></span>
            <ul>
                <li class="facebook-share">
                    <a id="flocks-facebook-share" href="#" title="<?php esc_attr_e('Share on Facebook', 'flocks');?>"></a>
                </li>
                <li class="twitter-share">
                    <a id="flocks-twitter-share" href="#" title="<?php esc_attr_e('Share on Twitter', 'flocks');?>"></a>
                </li>
                <li class="linkedin-share">
                    <a id="flocks-linkedin-share" href="#" title="<?php esc_attr_e('Share on LinkedIn', 'flocks');?>"></a>
                </li>
                <li class="google-plus-share">
                    <a id="flocks-gplus-share" href="#" title="<?php esc_attr_e('Share on Google+', 'flocks');?>"></a>
                </li>
                <li class="reddit-share">
                    <a id="flocks-reddit-share" href="#" title="<?php esc_attr_e('Share on Reddit', 'flocks');?>"></a>
                </li>
                <?php $mail_link = sprintf( "mailto:?&subject=%s&body=%s", esc_attr( get_the_title() ), get_the_permalink() ); ?>
                <li class="email-share">
                    <a id="flocks-email-share" href="<?php echo esc_url( $mail_link ); ?>" title="<?php esc_attr_e('E-mail to friend', 'flocks');?>"></a>
                </li>
            </ul>

            <?php if ( get_the_author_meta( 'user_url', $post->author_id ) ) {?>
                <div class="entry-website-link">
                    <span class="fa fa-external-link"></span>
                    <a href="<?php echo nl2br( get_the_author_meta( 'user_url', $post->author_id ) ); ?>">
                        <?php echo nl2br( get_the_author_meta( 'user_url', $post->author_id ) ); ?>
                    </a>
                </div>
            <?php } ?>

        </div>
    <?php
    return;
 }


/**
 * Flocks Comment Template
 */
 function flocks_comment_template( $comment, $args, $depth ) {

    if ( 'div' === $args['style'] ) {
        $tag       = 'div';
        $add_below = 'comment';
    } else {
        $tag       = 'li';
        $add_below = 'div-comment';
    }

    ?>

    <<?php echo flocks_sanity_check( $tag ) ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">

    <?php if ( 'div' != $args['style'] ) : ?>
        <div id="div-comment-<?php comment_ID() ?>" class="comment-body">
    <?php endif; ?>

        <div class="comment-author-column">
            <div class="comment-author vcard">
                <?php if ( $args['avatar_size'] != 0 )
                    echo get_avatar( $comment, 125 );
                ?>
            </div>
        </div>

        <div class="comment-author-context">
            <div class="comment-meta commentmetadata">

                <cite class="fn">
                    <?php echo get_comment_author_link(); ?>
                </cite>

                <div class="pull-right">
                    <a href="<?php echo htmlspecialchars( get_comment_link( $comment->comment_ID ) ); ?>" class="comemnt-date">
                        <?php
                            /* translators: 1: date, 2: time */
                            printf( esc_html__('%2$s - %1$s', 'flocks'), get_comment_date('j F Y'),  get_comment_time('h:i A') );
                        ?>
                    </a>

                    <?php comment_slashes(); ?>

                    <?php edit_comment_link( esc_attr__( 'Edit', 'flocks' ), '  ', '' ); ?>

                    <div class="reply">

                        <?php comment_slashes(); ?>

                        <?php comment_reply_link( array_merge( $args, array( 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?>

                    </div>
                </div>

            </div>

            <?php comment_text(); ?>

            <?php if ( $comment->comment_approved == '0' ) : ?>
            <p>
                <strong class="comment-awaiting-moderation">
                    <?php esc_html_e( 'Your comment is awaiting moderation.', 'flocks' ); ?>
                </strong>
            </p>
            <?php endif; ?>
        </div>


    <?php if ( 'div' != $args['style'] ) : ?>

    </div>

    <?php endif; ?>
    <?php
}

function comment_slashes() { ?>

    <?php if ( is_user_logged_in() ) { ?>

        <span class="comment-slashes">
            <?php esc_attr_e('/', 'flocks' ); ?>
        </span>

    <?php } ?>
    <?php
}

add_action( 'wp_enqueue_scripts', 'flocks_global_js_vars' );

function flocks_global_js_vars() {

    $sticky_header = 'true';

    $flocks_disabled_sticky_header = absint( get_theme_mod( 'flock_disable_sticky_header', 1 ) );

    if ( $flocks_disabled_sticky_header ===  0 ) {
        $sticky_header = 'false';
    }

    // Localize the script with new data.
    $translation_array = array(
        'ajax_url' => esc_url( admin_url( 'admin-ajax.php') ),
        'sticky_header' => $sticky_header,
        'gears_login_success' => esc_html__('Successfully logged-in. Redirecting in few seconds ...', 'flocks' )
    );

    // Attach localisation to our main script.
    wp_localize_script( 'flocks-script', 'flocks_global_js_vars', $translation_array );

    // Enqueued script with localized data.
    wp_enqueue_script( 'flocks-js-globals' );

    return;

}


/**
 * Hook post meta layout to 'flocks_main_section_class' filter
 */
add_filter( 'flocks_main_section_class', 'flocks_main_section_class_cb' );

function flocks_main_section_class_cb( $classes_collection ) {

        $post_id = get_queried_object_id();

        // if there is no post id, try fetching the queried object id
        if ( empty( $post_id ) ) {
            
            $object_id = get_queried_object_id();

            if ( ! empty( $object_id ) ) {

                $post_id = $object_id;

            }
        }

        $post_layout_meta = get_post_meta( $post_id, 'flocks_page_layout', true );

        if ( ! empty( $post_layout_meta ) ) {

            if ( 'sidebar-content' === $post_layout_meta ) {

                $classes_collection .= ' col-lg-push-3';

            }

            if ( 'full-content' === $post_layout_meta ) {

                $classes_collection .= ' content-full-width';

            }

        }


    return $classes_collection;
}

/**
 * Hook post meta layout to 'flocks_main_sidebar_class' filter
 */
add_filter( 'flocks_sidebar_section_class', 'flocks_sidebar_section_class_cb' );

function flocks_sidebar_section_class_cb( $classes_collection ) {

    $post_id = get_queried_object_id();

    // if there is no post id, try fetching the queried object id
    if ( empty( $post_id ) ) {
        
        $object_id = get_queried_object_id();

        if ( ! empty( $object_id ) ) {

            $post_id = $object_id;

        }
    }

    $post_layout_meta = get_post_meta( $post_id, 'flocks_page_layout', true );

    if ( ! empty( $post_layout_meta ) ) {

        if ( 'sidebar-content' === $post_layout_meta ) {

            $classes_collection .= ' col-lg-pull-9';

        }

        if ( 'full-content' === $post_layout_meta ) {

            $classes_collection .= ' hide';

        }

    }

    return $classes_collection;
}


/**
 * Facebook Sharer
 */

add_action('wp_enqueue_scripts', 'flocks_fb_article_sharer');

function flocks_fb_article_sharer() {

    if ( is_single() ) {
        
        $title = get_the_title();

        $permalink = get_the_permalink();

        $fb_sharer_url = sprintf("https://www.facebook.com/sharer/sharer.php?u=%s", $permalink );

        $tw_sharer_url = sprintf("http://twitter.com/share?text=%s&url=%s", esc_attr( $title ), $permalink );

        $li_sharer_url = sprintf("https://www.linkedin.com/shareArticle?mini=true&url=%s&title=%s", $permalink, esc_attr( $title ) );

        $gp_sharer_url = sprintf("https://plus.google.com/share?url=%s", $permalink );

        $rd_sharer_url = sprintf("http://www.reddit.com/submit?url=%s&title=%s", $permalink, esc_attr( $title ) );

        // Localize the script with new data.
        $translation_array = array(
            'fb_sharer_url' => $fb_sharer_url,
            'tw_sharer_url' => $tw_sharer_url,
            'li_sharer_url' => $li_sharer_url,
            'gp_sharer_url' => $gp_sharer_url,
            'rd_sharer_url' => $rd_sharer_url,
        );

        // Attach localisation to our main script.
        wp_localize_script( 'flocks-script', 'flocks_sharer_js_vars', $translation_array );

        // Enqueued script with localized data.
        wp_enqueue_script( 'flocks_sharer_js_vars' );


    }

    return;

}

function flocks_get_header_style() {

    $theme_mod_header = get_theme_mod( 'flocks_header_type', 'header-style-1');

    $header_style = sanitize_title( $theme_mod_header );

    if ( is_singular() ) { 

        $specific_post_header_style = get_post_meta( get_queried_object_id(), 'flocks_post_header_style', true ); 

        if ( ! empty( $specific_post_header_style ) ) { 

            if ( "default" ===  $specific_post_header_style ) { 
            
                return $header_style;

            } else { 

                return $specific_post_header_style; 

             } 

        } else { 

            return $header_style; 

        } 

    } else {

        return $header_style; 

    }

    return $header_style;

}

/**
 * Facebook
 */
add_filter( "gears_is_fb_enabled", "flocks_gears_is_fb_enabled" );

function flocks_gears_is_fb_enabled() {

   if ( 'enable' === get_theme_mod( 'enable_facebook_connect', 'enable' ) ) {

        return true;

   }
   
   return false;
}

add_filter("gears_fb_app_id", "flocks_gears_fb_app_id");

function flocks_gears_fb_app_id() {
    return get_theme_mod('facebook_api_id', '');
}

add_filter("gears_fb_app_secret", "flocks_gears_fb_app_secret");

function flocks_gears_fb_app_secret() {
    return get_theme_mod('facebook_api_secret', '');
}

add_filter("gears_button_label", "flocks_gears_facebook_connect_button_label");

function flocks_gears_facebook_connect_button_label() {
    return get_theme_mod('facebook_api_button_name', esc_html__('Facebook Connect', 'flocks'));
}

/**
 * Google Connect
 */
add_filter("gears_g+_api_enabled", "flocks_gears_gp_api_enabled");

function flocks_gears_gp_api_enabled() {
    
   if ( 'enable' === get_theme_mod( 'enable_google_connect', 'enable' ) ) {

        return true;

   }
   
   return false;

}

add_filter("gears_g+_app_id", "flocks_gears_gp_app_id");

function flocks_gears_gp_app_id() {
    return get_theme_mod('google_api_id', '');
}

add_filter("gears_g+_app_secret", "flocks_gears_gp_app_secrent");

function flocks_gears_gp_app_secrent(){
    return get_theme_mod('google_api_secret', '');
    
}

add_filter("gears_g+_btn_label", "flocks_gears_gp_btn_label");

function flocks_gears_gp_btn_label(){
    return get_theme_mod('google_api_button_name', esc_html__('Google Connect', 'flocks'));
};

add_filter("bp_xprofile_field_edit_html_elements", "flocks_bp_edit_html_elements");

function flocks_bp_edit_html_elements( $fields_value ){

    $fields_value['class'] = 'flocks_bp_edit_field';

    return $fields_value;
}


/**
 * Flocks WP Log-in Style
 * 
 * @return void
 */
// Login page styling disabled by Maarten
//add_action( 'login_enqueue_scripts', 'flocks_login_stylesheet' );

function flocks_login_stylesheet() {

    wp_enqueue_style( 'custom-login', get_stylesheet_directory_uri() . '/../flocks/css/wp-login.css' );
    //wp_enqueue_script( 'custom-login', get_stylesheet_directory_uri() . '/style-login.js' );

    return;
}

// Login page styling disabled by Maarten
//add_filter( 'login_headerurl', 'flocks_login_logo_url' );

function flocks_login_logo_url() {
    return esc_url( home_url('/') );
}

// Login page styling disabled by Maarten
//add_filter( 'login_headertitle', 'flocks_login_logo_url_title' );

function flocks_login_logo_url_title() {

    return esc_attr__( 'Go back to main page', 'flocks' );

}

// Gears login disabled by Maarten (dirty)
//add_action( 'login_message', 'flocks_gears_wp_login' );

function flocks_gears_wp_login() {
	// Line below added by Maarten: bugfix
	ob_start();
	?>
    <div class="gears-social-connect">
        <div class="gears-social-connect-heading">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-6">
                    <h3>
                        <?php esc_html_e( 'SOCIAL MEDIA LOGIN', 'flocks' ); ?>
                    </h3>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-6">
                    <?php  $register_link = wp_register( '', '', false ); ?>
                    <div class="pull-right register-link">
                        <?php esc_html_e( "Don't have an account yet? ", 'flocks' ); ?> 
                        <?php echo esc_url( $register_link ); ?>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <p>
                <?php esc_html_e('Sign in to our website with your favorite social media account. It is just one click away!', 'flocks'); ?>
            </p>
        </div>
        <div class="gears-social-connect-btns">
            <?php do_action( 'gears_login_form' ); ?>
        </div>
    </div><!--.gears-social-connect-->
	<?php 
	return ob_get_clean();
}

// Disabled by Maarten: is bugged
//add_action('login_footer', 'flocks_wp_login_forget_pass');

function flocks_wp_login_forget_pass() {

    echo '<div id="flocks-wp-login-lost-pass"><p><a href="'.esc_url(wp_lostpassword_url()).'" title="'.esc_attr('Click to Recover Password','flocks').'">'.esc_html__('Lost Password?', 'flocks').'</a></p></div>';
}

/**
 * WooCommerce Ajax Cart Total 
 */
add_filter( 'add_to_cart_fragments', 'flocks_woocommerce_header_add_to_cart_fragment' );

function flocks_woocommerce_header_add_to_cart_fragment( $fragments ) {

    global $woocommerce;
    
    ob_start();
    
    ?>
    
    <a class="flocks-cart-user-action" title="<?php esc_attr_e( 'View your shopping cart', 'flocks' ); ?>" href="<?php echo wc_get_cart_url(); ?>">

        <?php if ( 'header-style-3' === flocks_get_header_style() ) { ?>
            <i class="user-cart cart_light"></i>
        <?php } else { ?>
            <i class="user-cart"></i>
        <?php } ?>

        <span class="cart-count">
            <?php echo absint( WC()->cart->get_cart_contents_count() ); ?>
        </span>
    </a>

    <?php
    
    $fragments['a.flocks-cart-user-action'] = ob_get_clean();
    
    return $fragments;
}

/**
 * Get Flocks Background Image for Content Header.
 */
function flocks_get_content_header_meta() {

    // The global object ID. Works for both Posts and Taxonomies.
    $object_id = get_queried_object_id();

    // The default cover image.
    $default_content_header_bg = sprintf( '%s/assets/images/default-cover-image.jpg', get_template_directory_uri() );
    // Default meta values.
    $meta = array(
        'image' => get_theme_mod( 'flocks_content_header_image', esc_url ( $default_content_header_bg ) ),
        'sub_title' => get_theme_mod( 'flocks_content_header_sub_heading', '' ),
        'text_color' => get_theme_mod( 'flocks_content_header_color', '#ffffff' ),
        'background_color' => get_theme_mod( 'flocks_content_background_color', '#171715' ),
        'header_size' => get_theme_mod( 'flocks_content_background_heading_size', 'standard' ),
        'header_alignment' => get_theme_mod( 'flocks_content_background_heading_alignment', 'centered' ),
    );

    // Check if there is data inside the post meta.
    if ( is_singular() ) {

        $post_meta = array();

        $post_meta['image'] = get_post_meta( $object_id, 'flocks_mb_page_header_background', true );
        $post_meta['sub_title'] = get_post_meta( $object_id, 'flocks_mb_page_header_sub_title', true );
        $post_meta['background_color'] = get_post_meta( $object_id, 'flocks_mb_page_header_background_color', true );
        $post_meta['text_color'] = get_post_meta( $object_id, 'flocks_mb_page_header_text_color', true );
        $post_meta['header_size'] = get_post_meta( $object_id, 'flocks_mb_page_header_size', true );
        $post_meta['header_alignment'] = get_post_meta( $object_id, 'flocks_mb_page_header_alignment', true );

        foreach ( $post_meta as $post_meta_key => $post_meta_value ) {
            
            if ( ! empty ( $post_meta[$post_meta_key] ) ) {

                $meta[ $post_meta_key ] = $post_meta[$post_meta_key];

            }

        }

    }

    // For archives and taxonomies.
    if ( is_archive() ) {

        $tax_meta = array();

        $tax_meta['image'] = get_term_meta( $object_id, 'flocks_mb_page_header_background', true );
        $tax_meta['sub_title'] = get_term_meta( $object_id, 'description', true );
        $tax_meta['background_color'] = get_term_meta( $object_id, 'flocks_mb_page_header_background_color', true );
        $tax_meta['text_color'] = get_term_meta( $object_id, 'flocks_mb_page_header_text_color', true );
        $tax_meta['header_size'] = get_term_meta( $object_id, 'flocks_mb_page_header_size', true );
        $tax_meta['header_alignment'] = get_term_meta( $object_id, 'flocks_mb_page_header_alignment', true );

        foreach ( $tax_meta as $tax_meta_key => $tax_meta_value ) {
            
            if ( ! empty ( $tax_meta[$tax_meta_key] ) ) {

                $meta[ $tax_meta_key ] = $tax_meta[$tax_meta_key];

            }

        }

    }

    // For Blog Page.
    if ( flocks_is_blog() ) {

        $blog_meta['image'] = get_post_meta( $object_id, 'flocks_mb_page_header_background', true );
        $blog_meta['sub_title'] = get_post_meta( $object_id, 'flocks_mb_page_header_sub_title', true );
        $blog_meta['background_color'] = get_post_meta( $object_id, 'flocks_mb_page_header_background_color', true );
        $blog_meta['text_color'] = get_post_meta( $object_id, 'flocks_mb_page_header_text_color', true );
        $blog_meta['header_size'] = get_post_meta( $object_id, 'flocks_mb_page_header_size', true );
        $blog_meta['header_alignment'] = get_term_meta( $object_id, 'flocks_mb_page_header_alignment', true );

        foreach ( $blog_meta as $blog_meta_key => $blog_meta_value ) {
            
            if ( ! empty ( $blog_meta[$blog_meta_key] ) ) {

                $meta[ $blog_meta_key ] = $blog_meta[$blog_meta_key];

            }

        }
        
    }

    return $meta;

}


/**
 * Get flocks sign-in url
 *
 * @return string The url of the signin page.
 * @since  1.0
 * @package flocks\inc\
 */
function flocks_signin_url() {

    $theme_mod_signin_page = get_theme_mod( 'flocks_signin_page', false );

    if ( ! empty( $theme_mod_signin_page ) ) {

        $signin_page = get_post( absint( $theme_mod_signin_page ) );

        if ( ! empty ( $signin_page) ) {

            return get_permalink( $signin_page->ID );

        }

        return wp_login_url();

    }

    return wp_login_url();

}

/**
 * Flocks boxed or fluid layout handler
 * @since  1.0
 */
add_filter( 'body_class', 'flocks_site_layout' );

function flocks_site_layout( $classes ) {

    $classes[] = get_theme_mod( 'flocks_site_layout', 'fluid' );
    
    return $classes;
}

add_filter( 'body_class', 'flocks_inline_class' );

function flocks_inline_class( $classes ) {

    $classes[] = 'flocks-inline';
    
    return $classes;
}

add_filter( 'body_class', 'flocks_site_header' );

function flocks_site_header( $classes ) {
    $flocks_header_style = flocks_get_header_style();
    $classes[] = $flocks_header_style;
    return $classes;
}

function flocks_sanity_check( $var = '' ) {

    if ( empty ( $var ) ) {
        return '';
    }

    return $var;
}


function flocks_heading_inline_style() { 

    $inline_style = "body{background: red;}";

    $content_header = flocks_get_content_header_meta();

    $meta_header_background = $content_header['image'];
    $meta_header_background_color = $content_header['background_color'];
    $meta_header_text_color = $content_header['text_color'];

    ob_start();
    ?>
    .flocks-inline #cover-image {
        <?php if ( ! empty( $meta_header_background ) ) { ?>
        background-image: url('<?php echo esc_url( $meta_header_background ); ?>');
        <?php } ?>
        background-repeat: no-repeat;
        background-size: cover;
        background-color: #f6f8f9;
        background-position: center center;;
    }

    .flocks-inline #cover-image::after {
        <?php if ( ! empty ( $meta_header_background_color ) ) { ?>
            background: <?php echo esc_attr( $meta_header_background_color ); ?>;
        <?php } ?>
    }

    <?php if ( ! empty ( $meta_header_text_color ) ) { ?>
        .flocks-inline  #cover-image h1.entry-title, .heading-lead {
            color: <?php echo sanitize_hex_color( $meta_header_text_color ); ?>;
        }
    <?php } ?>

    <?php

    $inline_style = ob_get_clean();

    wp_add_inline_style( 'flocks-style', $inline_style );

}

add_action( 'wp_enqueue_scripts', 'flocks_heading_inline_style' );

function flocks_is_headline_enabled() {

    global $post;

    $global_settings = get_theme_mod( 'flocks_footer_headline_enabled', 'none' );

    $post_settings = get_post_meta( $post->ID, 'footer_headline_enabled', true );
    
    if ( is_single() ) {
        if ( ! empty ( $post_settings ) ) {
            if ( 'block' === $post_settings ) {
                return true;
            }
        } else {
            if ( 'block' === $global_settings ) {
                return true;
            }
        }
    } else {
        if ( 'block' === $global_settings ) {
            return true;
        }
    }

    return false;
    
}

function flocks_is_cta_enabled() {

    global $post;

    $global_settings = get_theme_mod( 'flocks_footer_cta_enabled', 'none' );

    $post_settings = get_post_meta( $post->ID, 'footer_cta_enabled', true );
    
    if ( is_single() ) {
        if ( ! empty ( $post_settings ) ) {
            if ( 'block' === $post_settings ) {
                return true;
            }
        } else {
            if ( 'block' === $global_settings ) {
                return true;
            }
        }
    } else {
        if ( 'block' === $global_settings ) {
            return true;
        }
    }

    return false;

}