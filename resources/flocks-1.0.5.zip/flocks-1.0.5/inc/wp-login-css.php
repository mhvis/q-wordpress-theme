<?php
/**
 * Handles the styling for default WP Login
 * 
 * @package flocks
 */

/**
 * Filter callback to login_enqueue_scripts
 * 
 * @return void
 */
function flocks_wp_login_logo() { 

	$site_logo_src = get_theme_mod( 'flocks_site_logo' );

	if ( empty( $site_logo_src ) ) {

		$site_logo_src = get_template_directory_uri() . '/logo.svg';

	}

	?>

    <style type="text/css">
        #login h1 a, .login h1 a {
            background-image: url('<?php echo esc_url( $site_logo_src ); ?>');
            padding-bottom: 30px;
        }
    </style>
<?php }

// Login page styling disabled by Maarten
//add_action( 'login_enqueue_scripts', 'flocks_wp_login_logo' );