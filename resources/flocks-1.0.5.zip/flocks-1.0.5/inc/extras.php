<?php
/**
 * Custom functions that act independently of the theme templates.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Flocks
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function flocks_body_classes( $classes ) {
	// Adds a class of group-blog to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}

	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of logged-out to the pages if there is no user that have logged-in.
	if ( ! is_user_logged_in() ) {
		$classes[] = 'logged-out';
	}


	return $classes;
}

add_filter( 'body_class', 'flocks_body_classes' );

add_filter('wp_nav_menu_items', 'flocks_search_after_menu', 10, 2);

function flocks_search_after_menu( $items, $args ) {

	if ( 'header-style-3' === get_theme_mod( 'flocks_header_type' ) ) {
		return $items;
	}

	if ( 'header-style-4' === get_theme_mod( 'flocks_header_type' ) ) {
		return $items;
	}

	if ( 'main' === $args->theme_location ):

		ob_start(); ?>

		<li class="menu-item flocks-menu-search">

			<a class="flocks-header-search-btn" title="<?php echo esc_attr( 'Search', 'flocks' );?>" href="#">

				<i class="fa fa-search"></i>

			</a>

			<div class="header-search-form">

				<?php echo get_search_form( false ); ?>

			</div>

		</li>

		<?php

		$items .= ob_get_clean();

	endif;

	return $items;
}

/**
 * Added Grid/List view functionality in
 * BuddyPress Members & Directory pages
 */
add_action( 'init', 'flocks_bp_set_current_directory_view' );

function flocks_bp_set_current_directory_view() {

	$valid_views = array( 'list', 'grid' );

	$members_view = filter_input( INPUT_GET, 'members_view', FILTER_SANITIZE_SPECIAL_CHARS );

	$groups_view = filter_input( INPUT_GET, 'groups_view', FILTER_SANITIZE_SPECIAL_CHARS );


	if ( ! empty( $members_view ) && in_array( $members_view, $valid_views ) ) {
		// 1 week duration
		setcookie( 'flocks_bp_members_view', $members_view, time() + 3600, "/" );
	}

	if ( ! empty( $groups_view ) && in_array( $groups_view, $valid_views ) ) {
		setcookie( 'flocks_bp_groups_view', $groups_view, time() + 3600, "/" );
	}

	return;
}

/**
 * Returns the current direcotry view
 */
function flocks_bp_get_current_directory_view() {

	$groups_view = 'grid';
	$members_view = 'grid';

	$valid_views = array( 'list', 'grid' );

	$params_groups_view = filter_input( INPUT_GET, 'groups_view', FILTER_SANITIZE_SPECIAL_CHARS );
	$params_members_view = filter_input( INPUT_GET, 'members_view', FILTER_SANITIZE_SPECIAL_CHARS );

	if ( isset( $_COOKIE['flocks_bp_members_view'] ) && in_array( $_COOKIE['flocks_bp_members_view'], $valid_views ) ) {
		$members_view = $_COOKIE['flocks_bp_members_view'];
	}

	if ( isset( $_COOKIE['flocks_bp_groups_view'] ) && in_array( $_COOKIE['flocks_bp_groups_view'], $valid_views ) ) {
		$groups_view = $_COOKIE['flocks_bp_groups_view'];
	}

	if ( !empty ( $params_members_view ) && in_array( $params_members_view, $valid_views ) ) {
		$members_view = $params_members_view;
	}

	if ( !empty ( $params_groups_view ) && in_array( $params_groups_view, $valid_views ) ) {
		$groups_view = $params_groups_view;
	}

	return array(
		'groups' => $groups_view,
		'members' => $members_view
	);

}

// Change WooCommerce Title
add_filter( 'get_the_archive_title', 'flocks_set_woocommerce_shop_title' );

function flocks_set_woocommerce_shop_title( $title ) {

	if ( function_exists( 'is_shop' ) ) {
		if ( is_shop() ) {
			$shop_id = get_option('woocommerce_shop_page_id');
			if ( ! empty( $shop_id ) ) {
				$shop = get_post( $shop_id );
				$allowed_tags = array(
					'em' => array(),
					'strong' => array()
				);
				if ( ! empty( $shop ) ) {
					return wp_kses( $shop->post_title, $allowed_tags );
				}
			}
		}
	}

	return $title;

}

// WooCommerce Template Overwrites
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

add_action('woocommerce_before_main_content', 'flocks_theme_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'flocks_theme_wrapper_end', 10);

function flocks_theme_wrapper_start() {
  	flocks_the_cover_image(); ?>
	<div id="printable-content">
		<div class="container">
			<div class="row">
				<div class="<?php echo apply_filters( 'flocks_main_section_class', 'col-lg-9' ); ?>">
					<div id="primary" class="content-area">
						<main id="main" class="site-main">

<?php
}

function flocks_theme_wrapper_end() { ?>
						</main><!--#main-->
					</div><!--#primary-->
				</div><!--col-lg-9-->
				<div class="<?php echo apply_filters( 'flocks_sidebar_section_class', 'col-lg-3' ); ?>">
					<?php get_sidebar(); ?>
				</div>
			</div><!--.row-->
		</div><!--.container-->
	</div><!--#printable-content-->
<?php
}

add_filter( 'woocommerce_product_add_to_cart_text', 'flocks_clear_archive_add_to_cart_text' );    // < 2.1
function flocks_clear_archive_add_to_cart_text() {
    return "";
}


// Disable BuddyPress Cover Photo
add_filter( 'bp_is_profile_cover_image_active', '__return_false' );

add_filter( 'bp_is_groups_cover_image_active', '__return_false' );

function flocks_get_the_archive_title( $title ) {

	$filterable_words = array( 'Category:', 'Archive:', 'Author:', 'Year:', 'Month:', 'Day:', 'Archives:', 'Tag:' );

	foreach ( $filterable_words as $filterable_word ) {
		
		$needle = $filterable_word;

		$haystack = $title;

		$pos = strpos( $haystack, $needle );

		if ( $pos !== false ) {

	    	return substr_replace( $haystack, $replace = "", $pos, strlen( $needle ) );

		}

	}

	return $title;

}

add_filter( 'get_the_archive_title', 'flocks_get_the_archive_title' );

function flocks_is_blog () {
	
	global  $post;
	
	$posttype = get_post_type ($post );

	return ( ((is_archive()) || (is_author()) || (is_category()) || (is_home()) || (is_tag())) && ( $posttype == 'post')  ) ? true : false ;
}
