<?php
/**
 * The template for displaying all forums.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Flocks
 */

get_header();

while ( have_posts() ) : the_post(); ?>

	<?php flocks_the_cover_image(); ?>

	<div id="printable-content">
		<div class="container">
			<div class="row">
				<div class="<?php echo apply_filters( 'flocks_main_section_class', 'col-lg-9' ); ?>">
					<div id="primary" class="content-area">
						<main id="main" class="site-main">
							<?php the_content(); ?>
						</main>
					</div>
				</div>
				<div class="<?php echo apply_filters( 'flocks_sidebar_section_class', 'col-lg-3' ); ?>">
					<?php get_sidebar(); ?>
				</div>
			</div>
		</div>
	</div>

<?php
endwhile; // End of the loop.
get_footer();
