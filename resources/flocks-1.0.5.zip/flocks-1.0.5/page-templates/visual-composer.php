<?php
/**
 * Template Name: Custom Visual Composer Page
 */

get_header();

if( have_posts() ){

    while( have_posts() ){

		the_post();

		do_action( 'flocks_before_page_content' ); ?>

        <div id="printable-content">
            <div class="container-fluid">
                <div class="row">
                        <div id="primary" class="content-area">
                            <main id="main" class="site-main">
                                <?php the_content(); ?>
                            </main>
                        </div>
                </div>
            </div>
        </div>
		<?php
	}
}

get_footer();
