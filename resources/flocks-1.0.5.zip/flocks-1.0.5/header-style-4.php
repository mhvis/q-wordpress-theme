<header id="masthead" class="site-header">

    <div id="site-branding-seo">
        <?php get_template_part( 'components/header/site', 'branding' ); ?>
    </div>

    <div class="container-fluid container">

        <div id="main-menu">
            <div class="row">
                <div class="col-lg-3 col-md-3">
                    <?php flocks_site_logo(); ?>
                </div>
                <div id="mobile-menu-toggle" class="visible-sm visible-xs">
                    <span class="menu-bar"></span>
                    <span class="menu-bar"></span>
                    <span class="menu-bar"></span>
                </div>
                <div class="hidden-sm hidden-xs col-lg-7 col-md-7">
                    <?php get_template_part( 'components/navigation/navigation', 'main' );?>
                </div>
                <div class="col-lg-2 col-md-2 pull-right">
                    <?php get_template_part( 'components/navigation/navigation', 'actions-style-4' );?>
                </div>
                <div class="mobile-menu visible-sm visible-xs">
                    <?php wp_nav_menu( array( 'theme_location' => 'main', 'menu_id' => 'mobile-main-menu-ul' ) ); ?>
                </div>
            </div>
        </div>

    </div>

</header>
