<form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div class="search-form-wrapper">
    	<?php $search_field_id = uniqid('s-'); ?>
        <label class="hidden screen-reader-text" for="<?php echo esc_attr( $search_field_id ); ?>"><?php esc_html_e('Search for:', 'flocks'); ?></label>
        <input type="search" value="" placeholder="<?php esc_attr_e('Search', 'flocks'); ?>" name="s" id="<?php echo esc_attr( $search_field_id ); ?>" />
        <button type="submit" class="searchsubmit">
            <i class="fa fa-search"></i>
        </button>
    </div>
</form>
