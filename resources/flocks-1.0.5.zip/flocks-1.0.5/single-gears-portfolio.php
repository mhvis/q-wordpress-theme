<?php
/**
 * The template for displaying single portfolio.
 *
 * @package Flocks
 */

get_header();

while ( have_posts() ) : the_post(); ?>

	<?php flocks_the_cover_image(); ?>

	<div id="printable-content">
		<div class="container">
			<div class="row">
				<div class="<?php echo apply_filters( 'flocks_main_section_class', 'col-lg-9' ); ?>">
					<div id="primary" class="content-area">
						<main id="main" class="site-main">
							<?php
								get_template_part( 'components/page/content', 'page' );
								// If comments are open or we have at least one comment, load up the comment template.
								if ( comments_open() || get_comments_number() ) :
									comments_template();
								endif;
							?>
						</main>
					</div>
				</div>
				<div class="<?php echo apply_filters( 'flocks_sidebar_section_class', 'col-lg-3' ); ?>">

					<section class="portfolio-meta client">
						<div class="portfolio-meta-title">
							<h4><?php esc_html_e('Client', 'flocks'); ?></h4>
						</div>
						<div class="portfolio-meta-value">
							<?php 
								$client = get_post_meta( get_the_ID(), 'gears_portfolio_client', true ); 
							?>
							<?php if ( ! empty( $client ) ) { ?>
								<p>
									<?php echo esc_html( $client  ); ?>
								</p>
							<?php } else { ?>
								<p>
									&mdash;
								</p>
							<?php } ?>
						</div>
					</section>
					
					<section class="portfolio-meta website">
						
						<div class="portfolio-meta-title">
							<h4><?php esc_html_e('Website', 'flocks'); ?></h4>
						</div>
						
						<div class="portfolio-meta-value">
							
							<?php 
								$website = get_post_meta( get_the_ID(), 'gears_portfolio_website', true ); 
							?>
							<?php if ( ! empty( $website ) ) { ?>
								<p>
									<a target="_blank" href="<?php echo esc_url( $website ); ?>" title="<?php echo esc_attr(the_title() ); ?>">
										<?php echo esc_url( $website ); ?>
									</a>
								</p>
							<?php } else { ?>
								<p>
									&mdash;
								</p>
							<?php } ?>	

						</div>
					</section>
					
					<section class="portfolio-meta date">
						<div class="portfolio-meta-title">
							<h4><?php esc_html_e('Date', 'flocks'); ?></h4>
						</div>
						<div class="portfolio-meta-value">
							<?php 
								$date = get_post_meta( get_the_ID(), 'gears_portfolio_date', true ); 
							?>
							<?php if ( ! empty( $website ) ) { ?>
								
								<p><?php echo esc_html( $date ); ?></p>

							<?php } else { ?>
								<p>
									&mdash;
								</p>
							<?php } ?>	
						</div>
					</section>

					<section class="portfolio-meta navigation">
						<div class="navigation">
						<div class="row">
							<div class="prev-posts col-md-6">
								
								<?php previous_post_link(
									'%link', 
									sprintf( 
										esc_attr__('%s Previous', 'flocks' ), 
										'<i class="fa fa-arrow-left"></i>' 
									)
								); ?>
							</div>
							<div class="next-posts col-md-6">
								<?php next_post_link (
									'%link', 
									sprintf( 
										esc_attr__('Next %s', 'flocks'), 
										'<i class="fa fa-arrow-right"></i>' 
										)
									); 
								?>
								
							</div>
						</div>
						</div>
					</section>
					
				</div>
				
			</div>
		</div>
	</div>

<?php
endwhile; // End of the loop.
get_footer();
