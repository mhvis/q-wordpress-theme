<?php
add_action( 'cmb2_admin_init', 'flocks_register_cmb2_portfolio_fields' );
add_action( 'cmb2_admin_init', 'flocks_register_cmb2_header_fields' );
add_action( 'cmb2_admin_init', 'flocks_register_cmb2_fields' );
add_action( 'cmb2_admin_init', 'flocks_register_cmb2_footer_fields' );
add_action( 'cmb2_admin_init', 'flocks_register_cmb2_taxonomy_fields' );

/**
 * Register Portfolio Fields.
 * @return void
 */
function flocks_register_cmb2_portfolio_fields() {
  $prefix = 'flocks_portfolio_metabox';
   /**
   * Initiate the footer meta box.
   */
  $cmb = new_cmb2_box( array(
       'id'            => 'flocks_mb_portfolio',
       'title'         => esc_attr__( 'Porfolio', 'flocks' ),
       'object_types'  => array( 'gears-portfolio' ), // Post type
       'context'       => 'normal',
       'priority'      => 'high',
       'show_names'    => true, // Show field names on the left
    ) );

  $cmb->add_field( array(
    'name'    => esc_attr__('Client', 'flocks'),
    'desc'    => esc_attr__('Enter the Client Name', 'flocks'),
    'id'      => 'gears_portfolio_client',
    'type'    => 'text'
  ) );

  $cmb->add_field( array(
    'name'    => esc_attr__('Website Url', 'flocks'),
    'desc'    => esc_attr__('Enter the Client Website Url', 'flocks'),
    'id'      => 'gears_portfolio_website',
    'type'    => 'text'
  ) );

  $cmb->add_field( array(
    'name'    => esc_attr__('Date', 'flocks'),
    'desc'    => esc_attr__('Enter the Date', 'flocks'),
    'id'      => 'gears_portfolio_date',
    'type'    => 'text_date',
  ) );

}
/**
 * Register header options for individual post or pages.
 * @return void
 */
function flocks_register_cmb2_header_fields() {

  $prefix = 'flocks_header_metabox';

  /**
   * Initiate the footer meta box.
   */
  $cmb = new_cmb2_box( array(
       'id'            => 'flocks_mb_header',
       'title'         => esc_attr__( 'Header Style Options', 'flocks' ),
       'object_types'  => array( 'page', 'post', 'product', 'topic', 'forum', 'gears-portfolio' ), // Post type
       'context'       => 'normal',
       'priority'      => 'high',
       'show_names'    => true, // Show field names on the left
    ) );

  $cmb->add_field( array(
      'name'             => esc_attr__('Header Style', 'flocks'),
      'desc'             => esc_attr__('Select a specific header style for this page or post.', 'flocks'),
      'id'               => 'flocks_post_header_style',
      'type'             => 'select',
      'show_option_none' => false,
      'default'          => 'custom',
      'options'          => array(
          'default'        => esc_attr__( 'Use default (Customizer Value)', 'flocks' ),
          'header-style-1' => esc_attr__( 'Header Style 1 - Classic', 'flocks' ),
          'header-style-2' => esc_attr__( 'Header Style 2 - Minimal Classic', 'flocks' ),
          'header-style-3' => esc_attr__( 'Header Style 3 - Modern Transparent', 'flocks' ),
          'header-style-4' => esc_attr__( 'Header Style 4 - Minimal Modern Transparent', 'flocks' ),
      ),
  ) );

}

/**
 * Register footer options per page or post settings.
 * @return void
 */
function flocks_register_cmb2_footer_fields() {

  $prefix = 'flocks_footer_metabox';

  /**
   * Initiate the footer meta box.
   */
  $cmb = new_cmb2_box( array(
       'id'            => 'flocks_mb_footer',
       'title'         => __( 'Footer Headlines Options', 'flocks' ),
       'object_types'  => array( 'page', 'post', 'product', 'topic', 'forum', 'gears-portfolio' ), // Post type
       'context'       => 'normal',
       'priority'      => 'high',
       'show_names'    => true, // Show field names on the left
    ) );

  $cmb->add_field( array(
      'name' => esc_attr__('Show Footer Headline', 'flocks'),
      'id'   => 'footer_headline_enabled',
      'type' => 'radio_inline',
      'options' => array(
          'block' => __( 'Enabled', 'flocks' ),
          'none' => __( 'Disabled', 'flocks' )
      ),
      'default' => get_theme_mod( 'flocks_footer_headline_enabled', 'none' )
  ) );

  $cmb->add_field( array(
      'name' => esc_attr__('Show CTA', 'flocks'),
      'id'   => 'footer_cta_enabled',
      'type' => 'radio_inline',
      'options' => array(
          'block' => __( 'Enabled', 'flocks' ),
          'none' => __( 'Disabled', 'flocks' )
      ),
      'default' => get_theme_mod( 'flocks_footer_cta_enabled', 'none' )
  ) );

}

/**
 * Register Header Options
 * @return void
 */
function flocks_register_cmb2_fields() {

    $prefix = 'flocks_metabox';

   /**
    * Initiate the metabox
    */
   $cmb = new_cmb2_box( array(
       'id'            => 'flocks_mb_page_header',
       'title'         => esc_attr__( 'Headline Options', 'flocks' ),
       'object_types'  => array( 'page', 'post', 'product', 'topic', 'forum', 'gears-portfolio' ), // Post type
       'context'       => 'normal',
       'priority'      => 'high',
       'show_names'    => true, // Show field names on the left
   ) );

   /**
    * Background Image
    */
   $cmb->add_field( array(
       'name'    => esc_attr__( 'Background Image', 'flocks' ),
       'desc'    => esc_attr__( 'Upload an image or enter an URL. 1200 x 300 (4:1 Aspect Ratio)', 'flocks' ),
       'id'      => 'flocks_mb_page_header_background',
       'type'    => 'file',
       // Optional:
       'options' => array(
           'url' => true, // Hide the text input for the url
       ),
       'text'    => array(
           'add_upload_file_text' => 'Add File' // Change upload button text. Default: "Add or Upload File"
       ),
       'default' => get_theme_mod('flocks_content_header_image', sprintf( '%s/assets/images/default-cover-image.jpg', get_template_directory_uri() ))
   ) );

   /**
    * Sub Heading
    */
   $cmb->add_field( array(
        'name'    => esc_attr__('Optional Sub Heading', 'flocks'),
        'desc'    => esc_attr__('Populate the textarea to add a subheading text under the page title', 'flocks'),
        'default' => '',
        'id'      => 'flocks_mb_page_header_sub_title',
        'type'    => 'textarea_small'
    ) );

    /**
     * Text Color
     */
    $cmb->add_field( array(
        'name'    => esc_attr__('Text Color', 'flocks'),
        'id'      => 'flocks_mb_page_header_text_color',
        'type'    => 'colorpicker',
        'default' => get_theme_mod( 'flocks_content_header_color', '#fff' ),
     ) );

    /**
     * Background Color
     */
    $cmb->add_field( array(
        'name'    => esc_attr__('Background Color', 'flocks'),
        'id'      => 'flocks_mb_page_header_background_color',
        'type'    => 'colorpicker',
        'default' => '#171715',
     ) );


     /**
      * Heading Size
      */
     $cmb->add_field( array(
        'name'    => esc_attr__('Heading Size', 'flocks'),
        'id'      => 'flocks_mb_page_header_size',
        'type'    => 'radio_inline',
        'options' => array(
            'small' => __( 'Small', 'flocks' ),
            'standard' => __( 'Standard (Default)', 'flocks' ),
            'bigger'   => __( 'Bigger', 'flocks' ),
            'extra-large'     => __( 'Extra Large', 'flocks' ),
        ),
        'default' => get_theme_mod( 'flocks_content_background_heading_size', 'standard' ),
    ));

     /**
      * Text Alignment
      */
     $cmb->add_field( array(
        'name'    => esc_attr__('Heading Alignment', 'flocks'),
        'id'      => 'flocks_mb_page_header_alignment',
        'type'    => 'radio_inline',
        'options' => array(
            'align-left' => esc_attr__( 'Align Left', 'flocks' ),
            'align-center' => esc_attr__( 'Centered (Default)', 'flocks' ),
            'align-right'   => esc_attr__( 'Align Right', 'flocks' ),
        ),
        'default' => get_theme_mod( 'flocks_content_background_heading_alignment', 'align-center' ),
    ));
}


/**
 * CMB Fields for Taxonomies.
 */
function flocks_register_cmb2_taxonomy_fields() {

    $prefix = 'flocks_taxonomy_metabox';

   /**
    * Initiate the metabox
    */
   $cmb_taxonomy = new_cmb2_box( array(
       'id'            => 'flocks_mb_taxonomy_page_header',
       'title'         => esc_attr__( 'Headline Options', 'flocks' ),
       'object_types'  => array( 'term' ), // Post type
       'context'       => 'normal',
       'priority'      => 'high',
       'taxonomies'    => array('category', 'post_tag'),
       'show_names'    => true, // Show field names on the left
   ) );

   // Background Image
   $cmb_taxonomy->add_field( array(
       'name'    => esc_attr__( 'Background Image', 'flocks' ),
       'desc'    => esc_attr__( 'Upload an image or enter an URL. 1200 x 300 (4:1 Aspect Ratio)', 'flocks' ),
       'id'      => 'flocks_mb_page_header_background',
       'type'    => 'file',
       'default' => get_theme_mod('flocks_content_header_image', sprintf( '%s/assets/images/default-cover-image.jpg', get_template_directory_uri() )),
       // Optional:
       'options' => array(
           'url' => true, // Hide the text input for the url
       ),
       'text'    => array(
           'add_upload_file_text' => esc_attr__('Add File', 'flocks') // Change upload button text. Default: "Add or Upload File"
       ),
   ) );

    // Text Color
    $cmb_taxonomy->add_field( array(
        'name'    => esc_attr__('Text Color', 'flocks'),
        'id'      => 'flocks_mb_page_header_text_color',
        'type'    => 'colorpicker',
        'default' => get_theme_mod( 'flocks_content_header_color', '#fff' ),
     ) );

    // Background Color
    $cmb_taxonomy->add_field( array(
        'name'    => esc_attr__('Background Color', 'flocks'),
        'id'      => 'flocks_mb_page_header_background_color',
        'type'    => 'colorpicker',
        'default' => '#171715',
     ) );


     // Heading Size
     $cmb_taxonomy->add_field( array(
        'name'    => esc_attr__('Heading Size', 'flocks'),
        'id'      => 'flocks_mb_page_header_size',
        'type'    => 'radio_inline',
        'options' => array(
            'small'    => esc_attr__( 'Small', 'flocks' ),
            'standard' => esc_attr__( 'Standard (Default)', 'flocks' ),
            'bigger'   => esc_attr__( 'Bigger', 'flocks' ),
            'extra-large' => esc_attr__( 'Extra Large', 'flocks' ),
        ),
        'default' => get_theme_mod( 'flocks_content_background_heading_size', 'standard' ),
    ) );

   /**
    * Text Alignment
    */
    $cmb_taxonomy->add_field( array(
        'name'    => esc_attr__('Heading Alignment', 'flocks'),
        'id'      => 'flocks_mb_page_header_alignment',
        'type'    => 'radio_inline',
        'options' => array(
            'align-left' => esc_attr__( 'Align Left', 'flocks' ),
            'align-center' => esc_attr__( 'Centered (Default)', 'flocks' ),
            'align-right'   => esc_attr__( 'Align Right', 'flocks' ),
        ),
        'default' => get_theme_mod( 'flocks_content_background_heading_alignment', 'align-center' ),
    ));
}
?>