<?php
extract(
    shortcode_atts( 
        array(
            'posts_per_page' => 3,
        ), $atts 
    )
);

$args = array(
    'ignore_sticky_posts' => 'true',
    'posts_per_page' => $posts_per_page
);
?>

<?php $gears_rp_query = new WP_Query( $args ); ?>

<?php if ( $gears_rp_query->have_posts() ) { ?>

    <div class="gears-recent-posts flocks-isotope">

        <?php while ( $gears_rp_query->have_posts() ) { ?>
        
            <div class="col-md-4 col-sm-6 col-xs-12">

                <article <?php echo post_class( array( 'gears-article-recent-posts' ) ); ?>>

                    <?php $gears_rp_query->the_post(); ?>

                    <header>
                        <div class="entry-thumbnail">

                            <div class="entry-post-format-icon">

                                <?php $format = get_post_format() ? : 'standard'; ?>

                                <?php if ( 'standard' === $format ) { ?>
                                    <span class="fa fa-file-text-o"></span>
                                <?php } ?>

                                <?php if ( 'aside' === $format ) { ?>
                                    <span class="fa fa-file-text-o"></span>
                                <?php } ?>

                                <?php if ( 'video' === $format ) { ?>
                                    <span class="fa fa-file-movie-o"></span>
                                <?php } ?>

                                <?php if ( 'image' === $format ) { ?>
                                    <span class="fa fa-camera"></span>
                                <?php } ?>

                                <?php if ( 'qoute' === $format ) { ?>
                                    <span class="fa fa-file-text-o"></span>
                                <?php } ?>

                                <?php if ( 'link' === $format ) { ?>
                                    <span class="fa fa-file-text-o"></span>
                                <?php } ?>

                            </div>

                            <?php if ( has_post_thumbnail() ) { ?>

                                <?php the_post_thumbnail( 'medium_large' ); ?>

                            <?php } else { ?>

                                <?php $default_thumb = plugins_url( 'gears/assets/images/default-thumbnail.png' ); ?>

                                <img class="attachment-post-thumbnail"
                                src="<?php echo esc_url( $default_thumb ); ?>" alt="<?php esc_attr_e('Post Thumbnail', 'flocks'); ?>" />

                            <?php } ?>

                        </div>

                        <div class="entry-meta">

                            <ul>
                                <?php if ( function_exists( 'bp_core_get_userlink' ) ) { ?>
                                    <li class="author-link">
                                        <i class="fa fa-user"></i>
                                        <?php esc_attr_e('By', 'flocks'); ?>
                                        <?php echo bp_core_get_userlink( get_the_author_meta('ID') ); ?>
                                    </li>
                                <?php } else { ?>
                                    <li class="author-link">
                                        <i class="fa fa-user"></i>
                                        <?php esc_attr_e('By', 'flocks'); ?>
                                        <?php the_author_posts_link(); ?>
                                    </li>
                                <?php } ?>
                                <li><i class="fa fa-comments-o"></i> <?php comments_number(); ?></li>
                            </ul>
                        </div>
                        <div class="entry-title">
                            <h3>
                                <a href="<?php echo esc_url( the_permalink() );?>" title="<?php echo esc_attr( the_title() ); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h3>
                        </div>

                    </header>

                    <div class="entry-content">
                        <?php $excerpt = get_the_excerpt(); ?>
                        <?php $maxlength = 85; ?>

                        <?php if ( strlen( $excerpt ) <= $maxlength ) { ?>
                            <?php echo substr( $excerpt, 0, $maxlength ); ?>
                        <?php } else { ?>
                            <?php echo substr( $excerpt, 0, $maxlength ); ?>&hellip;
                        <?php } ?>
                    </div>

                    <div class="entry-footer">
                        <a class="readmore" href="<?php echo esc_url( the_permalink() ); ?>">
                            <?php esc_html_e('Read More', 'flocks'); ?>
                            <i class="fa fa-caret-right"></i>
                        </a>
                    </div>

                    <?php wp_reset_postdata(); ?>

                </article>
        </div>
        <?php } ?>
    </div>
<?php } ?>
