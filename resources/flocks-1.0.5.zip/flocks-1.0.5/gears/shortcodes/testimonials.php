<?php


extract( 
    shortcode_atts(  
        array(
            'posts_per_page' => 3,
            'slide_margin' => 20,
            'max_slides' => 7,
            'min_slides' => 2,
            'item_width' => 434,
        ), 
        $atts 
    )
);

$args = array(
        'ignore_sticky_posts' => 'true',
        'post_type' => 'gears-testimonial',
        'posts_per_page' => $posts_per_page
    );

$testimonials = new WP_Query( $args );

?>

<?php if ( $testimonials->have_posts() ): ?>

    <ul 

    data-slide-margin="<?php echo absint( esc_attr( $slide_margin ) ); ?>" 
    data-max-slides="<?php echo absint( esc_attr( $max_slides ) ); ?>" 
    data-min-slides="<?php echo absint( esc_attr( $min_slides ) ); ?>" 
    data-item-width="<?php echo absint( esc_attr( $item_width ) ); ?>" 

    class="gears-testimonial-carousel gears-carousel-standard">

        <?php while ( $testimonials->have_posts() ): ?>

            <li <?php post_class(); ?>>

                <?php $testimonials->the_post(); ?>

                <?php $rating   = get_post_meta( get_the_ID(), 'gears_testimonial_rating', true ); ?>

                <?php $author   = get_post_meta( get_the_ID(), 'gears_testimonial_author', true ); ?>

                <?php $title    = get_post_meta( get_the_ID(), 'gears_testimonial_position', true ); ?>

                <?php $company  = get_post_meta( get_the_ID(), 'gears_testimonial_company', true ); ?>

                <div class="gears-testimonials-item">

                    <div class="row">

                        <div class="col-md-3 col-sm-3 col-xs-3">

                            <div class="gears-testimonials-author-photo">

                                <?php if ( has_post_thumbnail() ) { ?>

                                    <?php the_post_thumbnail( 'thumbnail' ); ?>

                                <?php } ?>

                            </div>

                        </div>


                        <div class="col-md-9 col-sm-9 col-xs-9">

                            <div class="gears-testimonials-rating">

                                <?php $rating = intval ( $rating ); ?>

                                <?php for ( $i = 1 ; $i <= $rating; $i ++ ) { ?>

                                    <i class="fa fa-star"></i>

                                <?php } ?>

                            </div>

                            <div class="gears-testimonials-title">

                                <?php the_title('<h3>', '</h3>', true ) ;?>

                            </div>

                            <div class="gears-testimonials-content">

                                <?php the_content(); ?>

                            </div>

                            <div class="gears-testimonials-author">

                                <div class="gears-testimonial-author-name">

                                    <?php echo esc_html( $author );?>

                                </div>

                                <div class="gears-testimonial-author-title">

                                    <?php echo esc_html( $title ); ?>

                                </div>

                                <div class="gears-testimonial-author-company">

                                    <?php echo esc_html( $company ); ?>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </li>

        <?php endwhile; ?>

    </ul>
    
<?php endif; ?>

<?php wp_reset_postdata(); ?>
