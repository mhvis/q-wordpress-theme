<?php
$output = '';
extract(
    shortcode_atts( array(
        'type' => 'active',
        'max_item' => 10
    ), $atts )
);

// available columns are 1, 2, 3, and 4
$params = array(
    'type' => $type,
    'per_page' => $max_item
);

if ( function_exists( 'bp_has_members' ) ) {

    // begin bp members loop
    if ( bp_has_members( $params ) ) {

            $output .= '<div class="clearfix">';

                $output .= '<ul class="gears-bp-members-list clear">';

                    while( bp_members() ){

                        $output .= '<li class="clearfix bp-members-list-item ">';

                            bp_the_member();

                                $output .= '<a class="bp-members-list-item-a" href="'. bp_get_member_permalink() . '" title="'.bp_get_member_name().'">';

                                    $output .= bp_get_member_avatar( array(	'type' => 'full', 'class' => 'avatar' ));

                                $output .= '</a>';

                                $output .= '<div class="members-name">';

                                    $output .= '<h5>';

                                        $output .= '<a href="'. bp_get_member_permalink() . '" title="'.bp_get_member_name().'">';

                                            $output .= bp_get_member_name();

                                        $output .= '</a>';

                                    $output .= '</h5>';

                                    // do_action( 'bp_directory_members_item' );

                                $output .= '</div>';
                        $output .= '</li>';
                    }

                $output .= '</ul>';

            $output .= '</div>';

        echo apply_filters( 'flocks_gears_bp_members_list', $output );
    }

} else {

    echo  $this->bp_not_installed;

}
