<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Define 'Site Logo' Section in theme customzer
 */
Flocks_Kirki::add_section( 'flocks_site_layout', array(
    'title'          => esc_attr__( 'Layout', 'flocks' ),
    'description'    => esc_attr__( 'Select the best layout for your website.', 'flocks' ),
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
) );

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_site_layout',
	'label'       => esc_attr__( 'Site Layout', 'flocks' ),
	'section'     => 'flocks_site_layout',
	'default'     => 'fluid',
	'priority'    => 10,
	'multiple'    => 1,
	'description' => esc_attr__( 'By selecting the \'Fluid or Wide\' layout, the overall width of your website will adapt to any screen width of any size (100%). By selecting the \'Boxed\' layout option, the overall width of your site will be maxed out to 1360px and will not extend further.', 'flocks' ),
	'choices'     => array(
		'fluid' => esc_attr__( 'Fluid or Wide', 'flocks' ),
		'boxed' => esc_attr__( 'Boxed', 'flocks' ),
	),
) );


Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'color',
	'settings'    => 'flocks_primary_color',
	'label'       => esc_attr__( 'Site Primary Color', 'flocks' ),
	'section'     => 'flocks_site_layout',
	'default'     => '#22b5ce',
	'priority'    => 10,
	'transport'	  => 'postMessage',
	'description' => esc_attr__( 'Use the color picker to select an appropriate color for your website.', 'flocks' ),
	'js_vars'     => array(
			array(
					'element' => flocks_colors_get_elements( 'color' ),
					'function' => 'css',
					'property' => 'color'
				),
			array(
					'element' => flocks_colors_get_elements( 'color-buddypress' ),
					'function' => 'css',
					'property' => 'color'
				),
			array(
					'element' => flocks_colors_get_elements( 'background-color' ),
					'function' => 'css',
					'property' => 'background-color'
				),
			array(
					'element' => flocks_colors_get_elements( 'background-buddypress' ),
					'function' => 'css',
					'property' => 'background-color'
				),
			array(
					'element' => flocks_colors_get_elements( 'border-color' ),
					'function' => 'css',
					'property' => 'border-color'
				)
		),
	'output'     => array(
			array(
					'element' => flocks_colors_get_elements( 'color' ),
					'function' => 'css',
					'property' => 'color'
				),
			array(
				'element' => flocks_colors_get_elements( 'color-buddypress' ),
				'function' => 'css',
				'property' => 'color'
			),
			array(
					'element' => flocks_colors_get_elements( 'background-color' ),
					'function' => 'css',
					'property' => 'background-color'
				),
			array(
					'element' => flocks_colors_get_elements( 'background-buddypress' ),
					'function' => 'css',
					'property' => 'background-color'
				),
			array(
					'element' => flocks_colors_get_elements( 'border-color' ),
					'function' => 'css',
					'property' => 'border-color'
				)
		)
));
?>