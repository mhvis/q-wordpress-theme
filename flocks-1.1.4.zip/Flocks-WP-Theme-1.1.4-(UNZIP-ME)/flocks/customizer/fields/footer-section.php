<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 *  Footer Section
 */
Flocks_Kirki::add_section( 'flocks_footer', array(
    'title'          => esc_attr__( 'Footer Section', 'flocks' ),
    'description'    => esc_attr__( 'All customizations related to Flocks Headline.', 'flocks' ),
    'panel'          => '', // Not typically needed.
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '', // Rarely needed.
) );

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_footer_style',
	'label'       => esc_html__( 'Footer Style', 'flocks' ),
	'section'     => 'flocks_footer',
	'default'     => 'footer-style-1',
	'priority'    => 10,
	'choices'     => array(
		'footer-style-1'  => esc_attr__('Footer Style 1', 'flocks'),
		'footer-style-2'  => esc_attr__('Footer Style 2', 'flocks'),
		'footer-style-3'  => esc_attr__('Footer Style 3', 'flocks')
	),
) );

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'image',
	'settings'    => 'image_demo',
	'label'       => esc_attr__( 'Background Image', 'flocks' ),
	'description' => esc_attr__( 'Upload a background image for the site footer.', 'flocks' ),
	'section'     => 'flocks_footer',
	'default'     => esc_url( get_template_directory_uri() . '/assets/images/footer-bg.jpg' ),
	'priority'    => 10,
	'transport'   => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#site-footer-widgets.footer-style-3, #site-footer-widgets.footer-style-2',
			'function' => 'css',
			'property' => 'background-image'
		),
	),
	'output' => array(
		array(
			'element'  => '#site-footer-widgets.footer-style-3, #site-footer-widgets.footer-style-2',
			'function' => 'css',
			'property' => 'background-image',
			'value_pattern' => 'url($)'
		),
	),
	'active_callback' => array(
    	array(
    		'setting'  => 'flocks_footer_style',
    		'operator' => 'in',
    		'value'    => array( 'footer-style-2', 'footer-style-3' )
    	)
    )
) );

/**
 * Footer Extra Content for Style 2 and Style 3
 */
$default_flocks_footer_extra_content  = '<p><img id="site-logo-img-footer" src="'.esc_url(get_template_directory_uri() . '/logo-alternative.svg').'"></p>';
$default_flocks_footer_extra_content .= '<p>Flocks is the most innovative &amp; complete social networking theme for WordPress &amp; BuddyPress. It\'s worth a buck. Create website easily. Spend more of your time planning your business. Having a good WordPress theme can save you a lot of troubles</p>';

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'textarea',
	'settings' => 'flocks_footer_extra_content',
	'label'    => __( 'Extra Content', 'flocks' ),
	'section'  => 'flocks_footer',
	'default'  => $default_flocks_footer_extra_content,
	'priority' => 10,
	'transport'   => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-extra-content',
			'function' => 'html',
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-extra-content',
			'function' => 'html',
		),
	),
	'active_callback' => array(
    	array(
    		'setting'  => 'flocks_footer_style',
    		'operator' => 'in',
    		'value'    => array( 'footer-style-2', 'footer-style-3' )
    	)
    )
) );



Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'textarea',
	'settings' => 'flocks_footer_info_copyright',
	'label'    => __( 'Info Copyright', 'flocks' ),
	'section'  => 'flocks_footer',
	'default'  => esc_html__('Copyright &copy; 2017 Flocks Development', 'flocks'),
	'priority' => 10,
	'transport'   => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#site-copytext',
			'function' => 'html',
		),
	),
	'output' => array(
		array(
			'element'  => '#site-copytext',
			'function' => 'html',
		),
	),
) );


Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_footer_menu',
	'label'       => esc_html__( 'Site Footer Menu', 'flocks' ),
	'description'       => esc_html__( 'Footer Menu is a non-heirarchical 
		menu and will not honor heirarchy settings in the selected menu.', 'flocks' ),
	'section'     => 'flocks_footer',
	'default'     => 'top',
	'priority'    => 10,
	'choices'     => array(
		'top'  => esc_attr__('Top Menu', 'flocks'),
		'main'  => esc_attr__('Main Menu', 'flocks'),
		'footer'  => esc_attr__('Footer Menu', 'flocks')
	),
) );

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'textarea',
	'settings' => 'flocks_footer_info_text',
	'label'    => __( 'Info Text', 'flocks' ),
	'section'  => 'flocks_footer',
	'default'  => esc_html( get_bloginfo('description') . ' - ' . get_bloginfo('title') ),
	'priority' => 10,
	'transport'   => 'postMessage',
	'js_vars' => array(
		array(
			'element'  => '#footer-extratext',
			'function' => 'html',
		),
	),
	'output' => array(
		array(
			'element'  => '#footer-extratext',
			'function' => 'html',
		),
	),
) );
?>