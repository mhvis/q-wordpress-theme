<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Create new Customizer Section called 'Sign-in Page'
 */
Flocks_Kirki::add_section( 'flocks_signin', array(
    'title'          => esc_attr__( 'Sign-in Page', 'flocks' ),
    'description'    => esc_attr__( 'All settings related to the sign-in page.', 'flocks' ),
    'priority'       => 10,
) );

/**
 * 
 */
Flocks_Kirki::add_field( 'flocks_signin_page', array(
	'type'        => 'dropdown-pages',
	'settings'    => 'flocks_signin_page',
	'label'       => esc_attr__( 'Sign-in Page', 'flocks' ),
	'description' => sprintf( esc_attr__( 'Please select the page to use as the sign-in page of your website. %s shortcode in the selected page. Select blank (Select a Page) to use the default WordPress login page. %s Do not forget to check the Membership option in the Settings > General.', 'flocks' ), '<strong>Do not forget to add the "[gears_login]"</strong>', '<br><br>'),
	'section'     => 'flocks_signin',
	'priority'    => 10,
) );