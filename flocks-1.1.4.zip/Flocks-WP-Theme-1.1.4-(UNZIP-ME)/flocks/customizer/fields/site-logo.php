<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define 'Site Logo' Section in theme customzer
 */
Flocks_Kirki::add_section( 'flocks_logo', array(
    'title'          => esc_attr__( 'Site Logo', 'flocks' ),
    'description'    => esc_attr__( 'Upload your logo, resize, and position it accordingly.', 'flocks' ),
    'panel'          => '', // Not typically needed.
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '', // Rarely needed.
) );

/**
 * Image Upload Field
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'image',
	'settings'    => 'flocks_site_logo',
	'label'       => esc_attr__( 'Logo', 'flocks' ),
	'description' => esc_attr__( 'Upload your company logo. Must be an image.', 'flocks' ),
	'section'     => 'flocks_logo',
	'default'     => '',
	'priority'    => 10,
));

/**
 * Site Logo Size
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'slider',
	'settings'    => 'flocks_site_logo_size',
	'label'       => esc_attr__( 'Logo Size', 'flocks' ),
	'description' => esc_attr__( 'Adjust the size of your logo using the slider field above.', 'flocks' ),
	'section'     => 'flocks_logo',
	'default'     => 180,
	'transport'	  => 'postMessage',
	'choices'     => array(
		'min'  => '100',
		'max'  => '275',
		'step' => '1',
	),
	'js_vars' => array(
		array(
			'element'  => '#main-menu #site-logo-img',
			'function' => 'css',
			'property' => 'width',
			'units' => 'px'
		),
	),
	'output' => array(
		array(
			'element'  => '#main-menu #site-logo-img',
			'function' => 'css',
			'property' => 'width',
			'units' => 'px'
		),
	)
) );

/**
 * Logo Position Top
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'slider',
	'settings'    => 'flocks_site_logo_top',
	'label'       => esc_attr__( 'Top Position', 'flocks' ),
	'description' => esc_attr__( 'Adjust the horizontal placement of your logo.', 'flocks' ),
	'section'     => 'flocks_logo',
	'transport'	 => 'postMessage',
	'default'     => 0,
	'choices'     => array(
		'min'  => '-20',
		'max'  => '15',
		'step' => '1',
	),
	'js_vars' => array(
		array(
			'element'  => '#main-menu #site-logo-img',
			'function' => 'css',
			'property' => 'top',
			'units' => 'px'
		),
	),
	'output' => array(
		array(
			'element'  => '#main-menu #site-logo-img',
			'function' => 'css',
			'property' => 'top',
			'units' => 'px'
		),
	)
) );

/**
 * Logo Position Left
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'slider',
	'settings'    => 'flocks_site_logo_left',
	'label'       => esc_attr__( 'Left Position', 'flocks' ),
	'description' => esc_attr__( 'Adjust the vertical placement of your logo.', 'flocks' ),
	'section'     => 'flocks_logo',
	'default'     => 46,
	'transport'	=> 'postMessage',
	'choices'     => array(
		'min'  => '-20',
		'max'  => '100',
		'step' => '1',
	),
	'js_vars' => array(
		array(
			'element'  => '#main-menu #site-logo-img',
			'function' => 'css',
			'property' => 'left',
			'units' => 'px'
		),
	),
	'output' => array(
		array(
			'element'  => '#main-menu #site-logo-img',
			'function' => 'css',
			'property' => 'left',
			'units' => 'px'
		),
	)
) );
?>