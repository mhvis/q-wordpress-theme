<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

Flocks_Kirki::add_section( 'flocks_single_blog', array(
    'title'          => esc_attr__( 'Single Blog', 'flocks' ),
    'description'    => esc_attr__( 'All options related to single article or post page.', 'flocks' ),
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'panel'          => '', // Not typically needed.
    'theme_supports' => '', // Rarely needed.
) );


// Enable Disable Social Sharing
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_single_blog_social',
	'label'       => esc_attr__( 'Enable Social Sharing Icons', 'flocks' ),
	'section'     => 'flocks_single_blog',
	'description' => esc_attr__('Enable or Disable Social Sharing', 'flocks'),
	'default'     => 'inline-block',
	'priority'    => 10,
	'transport'	  => 'postMessage',
	'choices'     => array(
		'inline-block'  => esc_attr__( 'Enabled', 'flocks' ),
		'none' => esc_attr__( 'Disabled', 'flocks' ),
	),
	'js_vars'	=> array(
		array(
			'element' => '.single article .entry-share',
			'function' => 'css',
			'property' => 'display',
		),
	),
	'output' => array(
		array(
			'element' => '.single article .entry-share',
			'function' => 'css',
			'property' => 'display',
		),
	),

) );

// Enable Disable Author
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_single_blog_author_bio',
	'label'       => esc_attr__( 'Enable Author Bio', 'flocks' ),
	'section'     => 'flocks_single_blog',
	'description' => esc_attr__('Enable or Disable Blog Author Bio', 'flocks'),
	'default'     => 'inline-block',
	'priority'    => 10,
	'choices'     => array(
		'inline-block'  => esc_attr__( 'Enabled', 'flocks' ),
		'none' => esc_attr__( 'Disabled', 'flocks' ),
	),
	'transport' => 'postMessage',
	'js_vars'	=> array(
		array(
				'element' => '.single #primary .author-about',
				'function' => 'css',
				'property' => 'display',
			),
	),
	'output' => array(
		array(
				'element' => '.single #primary .author-about',
				'function' => 'css',
				'property' => 'display',
			),
	),
) );

// Typography
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'typography',
	'settings'    => 'flocks_single_blog_typography',
	'label'       => esc_attr__( 'Typography', 'flocks' ),
	'section'     => 'flocks_single_blog',
	'default'     => array(
		'font-family'    => 'Source Sans Pro',
		'variant'        => 'regular',
		'font-size'      => '14px',
		'color'          => '#777',
	),
	'priority'    => 10,
	'transport'  => 'postMessage',
	'js_vars'	=> array(
		array(
				'element' => '.single #primary .entry-content',
				'function' => 'css',
				'property' => 'font-family',
			),
	),
	'output' => array(
		array(
				'element' => '.single #primary .entry-content',
				'function' => 'css',
				'property' => 'font-family',
			),
	),
) );