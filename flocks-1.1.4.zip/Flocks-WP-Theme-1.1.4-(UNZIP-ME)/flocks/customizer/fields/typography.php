<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Create new Customizer Section called 'Header'
 */
Flocks_Kirki::add_section( 'flocks_typography', array(
    'title'          => esc_attr__( 'Typography', 'flocks' ),
    'description'    => esc_attr__( 'This is where you can change the theme fonts. You can change the menu, the heading, and the overall body font. ', 'flocks' ),
    'panel'          => '', // Not typically needed.
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '', // Rarely needed.
) );

/**
 * Menu Fonts
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'typography',
	'settings'    => 'flocks_menu_typography',
	'description' => esc_attr__('Select a Font Family for the theme top menu and main menu.', 'flocks'),
	'label'       => esc_attr__( 'Main Menu Font', 'flocks' ),
	'section'     => 'flocks_typography',
	'transport'   => 'postMessage',
	'default'     => array(
		'font-family'    => 'Source Sans Pro',
		'variant'        => '400',
		'letter-spacing' => '0',
		'subsets'        => array( 'latin-ext' ),
	),
	'priority'    => 10,
	'output'      => array(
		array(
			'element' => '#masthead',
		),
	),
) );


/**
 * Header Fonts
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'typography',
	'settings'    => 'flocks_heading_typography',
	'description' => esc_attr__('Select a Font Family for the theme heading font. This will be applied to h1, h2, h3, h4, h5, and h6 tags or classes.', 'flocks'),
	'label'       => esc_attr__( 'Heading Font', 'flocks' ),
	'section'     => 'flocks_typography',
	'transport'   => 'postMessage',
	'default'     => array(
		'font-family'    => 'Poppins',
		'variant'        => '600',
		'letter-spacing' => '0',
		'subsets'        => array( 'latin-ext' ),
		'color'          => '#777'
	),
	'priority'    => 10,
	'output'      => array(
		array(
			'element' => 'h1, h2, h3, h4, h5, h6, .h1, .h2, .h3, .h4, .h5, .h6',
		),
	),
) );

/**
 * Body Fonts
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'typography',
	'settings'    => 'flocks_typography',
	'label'       => esc_attr__( 'Body Font', 'flocks' ),
	'section'     => 'flocks_typography',
	'description' => esc_attr__('Select a Font Family for the overall theme\'s design. This will be applied to the \'body\' tag.', 'flocks'),
	'transport'   => 'postMessage',
	'default'     => array(
		'font-family'    => 'Source Sans Pro',
		'variant'        => 'regular',
		'font-size'      => '14px',
		'line-height'    => '1.6',
		'letter-spacing' => '0',
		'subsets'        => array( 'latin-ext' ),
		'color'          => '#777'
	),
	'priority'    => 10,
	'output'      => array(
		array(
			'element' => 'body',
		),
	),
) );
?>