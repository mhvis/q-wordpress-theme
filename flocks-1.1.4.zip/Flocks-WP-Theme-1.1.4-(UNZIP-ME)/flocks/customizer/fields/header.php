<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/**
 * Create new Customizer Section called 'Header'
 */
Flocks_Kirki::add_section( 'flocks_header', array(
    'title'          => esc_attr__( 'Header', 'flocks' ),
    'description'    => esc_attr__( 'All customizations related to Flocks header.', 'flocks' ),
    'panel'          => '', // Not typically needed.
    'priority'       => 10,
    'capability'     => 'edit_theme_options',
    'theme_supports' => '', // Rarely needed.
) );

/**
 * Add new field to 'Header' section.
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'settings' => 'flocks_header_type',
	'label'    => esc_attr__( 'Header Style', 'flocks' ),
	'section'  => 'flocks_header',
	'type'     => 'select',
	'priority' => 10,
	'default'  => 'header-style-1',
    'choices'     => array(
		'header-style-1' => esc_attr__( 'Header 1', 'flocks' ),
		'header-style-2' => esc_attr__( 'Header 2', 'flocks' ),
		'header-style-3' => esc_attr__( 'Header 3', 'flocks' ),
		'header-style-4' => esc_attr__( 'Header 4', 'flocks' ),
	),
) );

/**
 * Social Links for Header 1
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'repeater',
	'label'       => esc_attr__( 'Top Menu Links (Social Media)', 'flocks' ),
	'section'     => 'flocks_header',
	'priority'    => 10,
	// 'transport'	  => 'postMessage', Having Errors when set to PostMessage
	'settings'    => 'flocks_top_social',
	'description' => esc_attr__('Add or modify the social links in the "Header Style 1". Visit http://fontawesome.io/icons/ for "Social Media Icon" reference.', 'flocks'),
	'default'     => array(
		array(
			'link_icon' => 'dribbble',
			'link_url'  => 'https://dribbble.com/yourdribbbleusername',
		),
		array(
			'link_icon' => 'google-plus',
			'link_url'  => 'https://plus.google.com/100811092185688583710',
		),
		array(
			'link_icon' => 'twitter',
			'link_url'  => 'https://twitter.com/DSCOfficial',
		),
		array(
			'link_icon' => 'facebook',
			'link_url'  => 'https://facebook.com/DSCOfficial/',
		),
	),
	'fields' => array(
		'link_icon' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'Social Media Icon', 'flocks' ),
			'description' => esc_attr__( 'This will be the icon for your link', 'flocks' ),
			'default'     => '',
		),
		'link_url' => array(
			'type'        => 'text',
			'label'       => esc_attr__( 'Social Media Link Url', 'flocks' ),
			'description' => esc_attr__( 'This will be the link to your social media page', 'flocks' ),
			'default'     => '',
		),
	),
	'active_callback' => array(
    	array(
    		'setting'  => 'flocks_header_type',
    		'operator' => 'in',
    		'value'    => array(
                'header-style-1'
            ),
    	)
    )
) );

/**
 * Top Menu Phone Number Field
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'flocks_top_menu_phone',
	'label'       => esc_attr__( 'Top Menu Phone', 'flocks' ),
	'section'     => 'flocks_header',
	'default'     => 'inline-block',
	'priority'    => 10,
	'transport' => 'postMessage',
	'choices'     => array(
		'inline-block'  => esc_attr__( 'Show Top Menu Phone Number', 'flocks' ),
		'none' => esc_attr__( 'Hide Top Menu Phone Number', 'flocks' ),
	),
	'active_callback' => array(
    	array(
    		'setting'  => 'flocks_header_type',
    		'operator' => 'in',
    		'value'    => array( 'header-style-1' )
    	)
    ),
	'js_vars' => array(
		array(
			'element'  => '#social-top-menu li#flocks-phone',
			'function' => 'css',
			'property' => 'display',
		),
	),
	'output' => array(
		array(
			'element'  => '#social-top-menu li#flocks-phone',
			'function' => 'css',
			'property' => 'display',
		),
	)
));

Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'     => 'text',
	'settings' => 'flocks_top_menu_phone_number',
	'label'    => esc_attr__( 'Phone Number', 'flocks' ),
	'section'  => 'flocks_header',
	'default'  => esc_attr__( '+123-456-7890', 'flocks' ),
	'priority' => 10,
	'transport' => 'postMessage',
	'active_callback' => array(
    	array(
    		'setting'  => 'flocks_top_menu_phone',
    		'operator' => '==',
    		'value'    => 'inline-block'
    	),
		array(
			'setting'  => 'flocks_header_type',
			'operator' => 'in',
			'value'    => array( 'header-style-1' )
		)
    ),
	'js_vars'   => array(
		array(
			'element'  => '#flocks-phone-number',
			'function' => 'html',
		),
	)
) );

/**
 * Main Menu Float
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'settings' => 'flocks_menu_float',
	'label'    => esc_attr__( 'Header Menu Float', 'flocks' ),
	'section'  => 'flocks_header',
	'type'     => 'select',
	'priority' => 10,
	'transport' => 'postMessage',
	'default'  => 'float-left',
    'choices'     => array(
		'left' => esc_attr__( 'Left', 'flocks' ),
		'right' => esc_attr__( 'Right', 'flocks' ),
	),
	'js_vars' => array(
		array(
			'element'  => '#main-menu ul#main-menu-ul',
			'function' => 'css',
			'property' => 'float',
		),
	),
	'output' => array(
		array(
			'element'  => '#main-menu ul#main-menu-ul',
			'function' => 'css',
			'property' => 'float',
		),
	)
) );

/**
 * Search Enable or Disable
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'select',
	'settings'    => 'header_enabled_search',
	'label'       => esc_attr__( 'Enable Search in Menu', 'flocks' ),
    'description' => esc_attr__( "Enable to activate the search function in the menu, otherwise, use Disable.", 'flocks' ),
	'section'     => 'flocks_header',
	'default'     => 'inline-block',
	'priority'    => 10,
	'transport'	  => 'postMessage',
	'choices'     => array(
		'inline-block'  => esc_attr__( 'Enable', 'flocks' ),
		'none' => esc_attr__( 'Disable', 'flocks' ),
	),
	'js_vars' => array(
		array(
			'element'  => 'li.menu-item.flocks-menu-search',
			'function' => 'css',
			'property' => 'display',
		),
		array(
			'element' => '.li-main-menu-search',
			'function' => 'css',
			'property' => 'display',
		)
	),
	'output' => array(
		array(
			'element'  => 'li.menu-item.flocks-menu-search',
			'function' => 'css',
			'property' => 'display',
		),
		array(
			'element' => '.li-main-menu-search',
			'function' => 'css',
			'property' => 'display',
		)
	)
) );

/**
 * Cart Preview
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'switch',
	'settings'    => 'flock_disable_cart',
	'label'       => esc_attr__( 'Cart Preview', 'flocks' ),
    'description' => esc_attr__( "Enable to show the number of items in your cart in header, otherwise, disable. Only works for 'Header Style 1' and 'Header Style2'", 'flocks' ),
	'section'     => 'flocks_header',
	'default'     => 'on',
	'priority'    => 10,
	'choices'     => array(
		'on'  => esc_attr__( 'Enable', 'flocks' ),
		'off' => esc_attr__( 'Disable', 'flocks' ),
	),
    'active_callback' => array(
    	array(
    		'setting'  => 'flocks_header_type',
    		'operator' => 'in',
    		'value'    => array(
                'header-style-1', 'header-style-2'
            ),
    	)
    )
) );

/**
 * Stick Header Option
 */
Flocks_Kirki::add_field( 'flocks_customizer_config', array(
	'type'        => 'switch',
	'settings'    => 'flock_disable_sticky_header',
	'label'       => esc_attr__( 'Sticky Header', 'flocks' ),
    'description' => esc_attr__( "Enable to make the header sticky on scroll, otherwise, use Disable.", 'flocks' ),
	'section'     => 'flocks_header',
	'default'     => '1',
	'priority'    => 10,
	'choices'     => array(
		'on'  => esc_attr__( 'Enable', 'flocks' ),
		'off' => esc_attr__( 'Disable', 'flocks' ),
	)
) );
