<?php
    $mobile_menu = wp_nav_menu(
        array(
            'fallback_cb' => false,
            'echo' => false,
            'theme_location' => 'main',
            'menu_id' =>
            'mobile-main-menu-ul'
        )
    );
?>
<header id="masthead" class="site-header">

    <div id="site-branding-seo">
        <?php get_template_part( 'components/header/site', 'branding' ); ?>
    </div>

    <div class="container-fluid desktop-menu">

        <div id="top-menu-container" class="row">
            <?php get_template_part( 'components/navigation/navigation', 'top' ); ?>
        </div>

        <div id="main-menu" class="">
            <div class="row">
                <div class="header-col-left col-lg-3 col-md-3 col-sm-3">
                    <?php flocks_site_logo(); ?>
                    <div class="clearfix"></div>
                </div>
                <div class="mobile-menu-search visible-sm visible-xs">
                    <a href="#" title="<?php esc_attr_e('Search', 'flocks'); ?>" id="flocks-search-btn">
                        <i class="fa fa-search"></i>
                    </a>
                    <div id="top-right-search-form">
                        <div id="close-top-right-search-form" class="visible-sm visible-xs">
                            <span class="menu-bar"></span>
                            <span class="menu-bar"></span>
                        </div>
        				<?php echo get_search_form( false ); ?>
        			</div>
                </div>
                <?php if ( ! empty( $mobile_menu ) ) { ?>
                    <div id="mobile-menu-toggle" class="visible-sm visible-xs">
                        <span class="menu-bar"></span>
                        <span class="menu-bar"></span>
                        <span class="menu-bar"></span>
                    </div>
                <?php } ?>
                <!-- main menu -->
                <div class="hidden-sm hidden-xs header-col-center col-lg-6 col-md-7 col-sm-6">
                    <?php get_template_part( 'components/navigation/navigation', 'main' );?>
                </div>

                <div class="header-col-right col-lg-3 col-md-2 col-sm-12">
                    <?php get_template_part( 'components/navigation/navigation', 'actions' );?>
                </div>
                
                <div class="mobile-menu visible-sm visible-xs">
                    <?php echo ( $mobile_menu ); ?>
                </div>
            </div>
        </div>

    </div>

</header>
