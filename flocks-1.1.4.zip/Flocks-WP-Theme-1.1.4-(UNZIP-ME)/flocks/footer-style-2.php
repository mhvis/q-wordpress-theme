<?php
/**
 * Footer Style 2 File
 *
 * @since  1.0
 */
?>

<div id="site-footer-widgets" class="footer-style-2 site-footer-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div id="footer-style-2-text">
					<div id="footer-extra-content">
						<?php $flocks_footer_extra_content = get_theme_mod( 'flocks_footer_extra_content', false ); ?>
						<?php if ( false === $flocks_footer_extra_content ) { ?>
							<p> <?php flocks_site_logo( 'site-logo-img-footer' ); ?> </p>
							<p> <?php esc_html_e("Flocks is the most innovative &amp; complete social networking theme for WordPress &amp; BuddyPress. 
							It's worth a buck. Create website easily. Spend more of your time planning your business. 
							Having a good WordPress theme can save you a lot of troubles.", 'flocks'); ?> </p>
						<?php } else { ?>
							<?php echo wp_kses_post( $flocks_footer_extra_content ); ?>
						<?php } ?>
					</div><!--#footer-extra-content-->
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div id="widget-collections">
					<?php dynamic_sidebar('site-footer'); ?>
				</div>
			</div>
		</div>
	</div>
</div>