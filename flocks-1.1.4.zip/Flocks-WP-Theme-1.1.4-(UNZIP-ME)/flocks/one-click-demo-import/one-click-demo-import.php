<?php
function flocks_ocdi_import_files() {
    return array(
        // Demo 1 (Classic Default)
        array(
            'import_file_name'           => esc_html__('Original Classic', 'flocks'),
            // DEMO CATEGORY
            'categories'                 => array( esc_html__('Classic', 'flocks') ),
            // XML FILE URL
            'import_file_url'            => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/content.xml',
            // WIDGET FILE URL (.WIE)
            'import_widget_file_url'     => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/widgets.wie',
            // CUSTOMIZER .DAT
            'import_customizer_file_url' => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/customizer.dat',
            // PREVIEW IMAGE
            'import_preview_image_url'   => 'http://flocks.dunhakdis.com/preview/images/demo1.jpg',

            'import_notice'              => esc_html__( 'Sit back and relax. The import process usually finishes in 3 to 7 minutes depending on the download speed of your internet and the processing speed of your server or hosting.', 'flocks' ),
        ),
        // Demo 2 (Modern)
        array(
            'import_file_name'           => esc_html__('Modern', 'flocks'),
            // DEMO CATEGORY
            'categories'                 => array( esc_html__('Modern', 'flocks') ),
            // XML FILE URL  (same as default)
            'import_file_url'            => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/content.xml',
            // WIDGET FILE URL (.WIE) (same as default)
            'import_widget_file_url'     => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/widgets.wie',
            // CUSTOMIZER .DAT
            'import_customizer_file_url' => 'https://s3.amazonaws.com/dsc-plugins/demos/modern/customizer.dat',
            // PREVIEW IMAGE
            'import_preview_image_url'   => 'http://flocks.dunhakdis.com/preview/images/demo3.jpg',

            'import_notice'              => esc_html__( 'Sit back and relax. The import process usually finishes in 3 to 7 minutes depending on the download speed of your internet and the processing speed of your server or hosting.', 'flocks' ),
        ),
         // Demo 3 (Modern Minimal)
        array(
            'import_file_name'           => esc_html__('Modern Minimal', 'flocks'),
            // DEMO CATEGORY
            'categories'                 => array( esc_html__('Modern', 'flocks') ),
            // XML FILE URL
            'import_file_url'            => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/content.xml',
            // WIDGET FILE URL (.WIE)
            'import_widget_file_url'     => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/widgets.wie',
            // CUSTOMIZER .DAT
            'import_customizer_file_url' => 'https://s3.amazonaws.com/dsc-plugins/demos/modern-minimal/customizer.dat',
            // PREVIEW IMAGE
            'import_preview_image_url'   => 'http://flocks.dunhakdis.com/preview/images/demo4.jpg',

            'import_notice'              => esc_html__( 'Sit back and relax. The import process usually finishes in 3 to 7 minutes depending on the download speed of your internet and the processing speed of your server or hosting.', 'flocks' ),
        ),
        // Classic Minimal
        array(
            'import_file_name'           => esc_html__('Classic Minimal', 'flocks'),
            // DEMO CATEGORY
            'categories'                 => array( esc_html__('Classic', 'flocks') ),
            // XML FILE URL (same as default)
            'import_file_url'            => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/content.xml',
            // WIDGET FILE URL (.WIE) (same as default)
            'import_widget_file_url'     => 'https://s3.amazonaws.com/dsc-plugins/demos/flocks/main/widgets.wie',
            // CUSTOMIZER .DAT
            'import_customizer_file_url' => 'https://s3.amazonaws.com/dsc-plugins/demos/classic-minimal/customizer.dat',
            // PREVIEW IMAGE
            'import_preview_image_url'   => 'http://flocks.dunhakdis.com/preview/images/demo2.jpg',

            'import_notice'              => esc_html__( 'Sit back and relax. The import process usually finishes in 3 to 7 minutes depending on the download speed of your internet and the processing speed of your server or hosting.', 'flocks' ),
        ),    
    ); // returned array

}

add_filter( 'pt-ocdi/import_files', 'flocks_ocdi_import_files' );

function flocks_ocdi_before_widgets_import( $selected_import ) {
    
    update_option( 'sidebars_widgets', $null );

}

add_action( 'pt-ocdi/before_widgets_import', 'flocks_ocdi_before_widgets_import' );

function flocks_ocdi_after_import_setup( $selected_import ) {
  
    global $wp_rewrite;

    // Assign menus to their locations.
    $main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );

    $top_menu = get_term_by( 'name', 'Top Menu', 'nav_menu' );

    set_theme_mod( 'nav_menu_locations', array(
            'main' => $main_menu->term_id,
            'top' => $top_menu->term_id,

        )
    );

    // Assign front page and posts page (blog page).
    $front_page_id = get_page_by_title( 'Home' );

    $blog_page_id  = get_page_by_title( 'Blog' );

    update_option( 'show_on_front', 'page' );

    update_option( 'page_on_front', $front_page_id->ID );

    update_option( 'page_for_posts', $blog_page_id->ID );

    // Update BuddyPress options
    flocks_set_bp_options();

    $slider = 'home-slider-default';

    if ( 'Modern' === $selected_import['import_file_name'] ) {
        $slider = 'home-slider-modern';
    }

    if ( 'Modern Minimal' === $selected_import['import_file_name'] ) {
        $slider = 'home-slider-modern-minimalist';
    }

    if ( 'Classic Minimal' === $selected_import['import_file_name'] ) {
        $slider = 'home-slider-classic-minimal';
    }

    // Import Slider
    flocks_import_slider( $slider );
    
    // Set permalink
    $wp_rewrite->set_permalink_structure( '/%postname%/' );

    flush_rewrite_rules( $hard = true );

}

add_action( 'pt-ocdi/after_import', 'flocks_ocdi_after_import_setup' );

function flocks_import_slider( $slider = 'home-slider-default' ) {

  $flocks_home_slider = get_template_directory() . sprintf( '/demo/%s.zip', $slider );

    if ( file_exists( $flocks_home_slider ) ) {
    
        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        
        if ( class_exists('RevSlider') ) {
            $slider = new RevSlider();
            $slider->importSliderFromPost( true, true, $flocks_home_slider );
        }

    }

}

function flocks_set_bp_options() {

  $bp_pages = get_option('bp-pages');
  
  $members_page = get_page_by_path( 'members-2' );
  
  $groups_page = get_page_by_path( 'groups-2' );

  $activity_page = get_page_by_path( 'activity-2' );

  if ( isset ( $members_page->ID ) ):

    $bp_pages['members'] = $members_page->ID;

  endif;
  
  if ( isset ( $groups_page->ID ) ):

    $bp_pages['groups'] = $groups_page->ID;

  endif;

  if ( isset ( $activity_page->ID ) ):

    $bp_pages['activity'] = $activity_page->ID;
  
  endif;

  update_option( 'bp-pages', $bp_pages );

  return;
  
}
?>