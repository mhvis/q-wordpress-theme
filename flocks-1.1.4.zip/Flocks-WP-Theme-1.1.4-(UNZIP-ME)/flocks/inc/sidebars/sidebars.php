<?php
/**
 * Sidebars Action
 *
 * @package Thrive
 * @since 1.0
 */
DEFINE( 'FLOCKS_SIDEBAR_UNIQUE_ID', 'flocks_register_sidebar_settings_menu' );

add_action( 'init', 'flocks_sidebar_meta' );
add_action( 'wp_ajax_flocks_sidebar_add', 'flocks_sidebar_add' );
add_action( 'wp_ajax_flocks_sidebar_delete', 'flocks_sidebar_delete' );
add_action( 'wp_ajax_flocks_sidebar_update', 'flocks_sidebar_update' );
add_action( 'widgets_init', 'flocks_sidebar_register' );
add_action( 'admin_menu', 'flocks_register_sidebar_settings' );

function flocks_sidebar_meta() {

	require_once get_template_directory() . '/inc/sidebars/sidebars-meta.php';

	return;
}


function flocks_sidebar_register() {

	require_once get_template_directory() . '/inc/sidebars/sidebars-register.php';

	return;
}
/**
 * Register Unlimited Sidebar Option
 */
function flocks_register_sidebar_settings() {
	// add option page under appearance

	add_theme_page(
		esc_html__( 'Sidebars','flocks'),
		esc_html__('Sidebars','flocks'),
			'read',
			FLOCKS_SIDEBAR_UNIQUE_ID,
			'flocks_register_sidebar_settings_page'
	);
}

function flocks_register_sidebar_settings_page() {

	locate_template(
		array(
			'inc/sidebars/sidebars-screen.php'
		),
		true,
		true
	);

	return;

}


/**
 * Updates the sidebar.
 */
function flocks_sidebar_update(){

	// Check if user has the right to manage options.
	if( current_user_can( 'manage_options' ) ){

		$sidebar_id = esc_attr( $_POST['sidebar_id'] );

		if( empty( $sidebar_id ) ) die();

		$option_key = FLOCKS_SIDEBAR_UNIQUE_ID;
		$existing_sidebar = unserialize( get_option( $option_key ) );

		// Remove the sidebar from the serialized array.
		$existing_sidebar[ $sidebar_id ]['flocks-sidebar-name'] = esc_attr( $_POST['flocks-sidebar-name'] );
		$existing_sidebar[ $sidebar_id ]['flocks-sidebar-description'] = esc_attr( $_POST['flocks-sidebar-description'] );

		update_option( FLOCKS_SIDEBAR_UNIQUE_ID, serialize( $existing_sidebar ) );
		wp_safe_redirect( admin_url( 'themes.php?page='.FLOCKS_SIDEBAR_UNIQUE_ID.'&action=edit&sidebar=' . $sidebar_id ) );
	}

	die();
}
/**
 * Removes a sidebar
 */
function flocks_sidebar_delete(){

	// Check if user has the right to manage options.
	if( current_user_can( 'manage_options' ) ){

		$sidebar_id = esc_attr( $_GET['sidebar'] );

		if( empty( $sidebar_id ) ) die();

		$option_key = FLOCKS_SIDEBAR_UNIQUE_ID;
		$existing_sidebar = unserialize( get_option( $option_key ) );

		// Remove the sidebar from the serialized array.
		unset( $existing_sidebar[ $sidebar_id ] );
		update_option( FLOCKS_SIDEBAR_UNIQUE_ID, serialize( $existing_sidebar ) );
		wp_safe_redirect( admin_url( 'themes.php?page='.FLOCKS_SIDEBAR_UNIQUE_ID.'' ) );
	}

	die();

}
/**
 * adds new custom sidebar
 */
function flocks_sidebar_add(){

	// check if current user has the ability
	// to manage the option, most probably the
	// website administrator
	// @flocks version 1
	$option_key = FLOCKS_SIDEBAR_UNIQUE_ID; // to make sure the option is unique to avoid


	if( current_user_can('manage_options') ){

		$current_sidebars = unserialize( get_option( $option_key ) );

		// just insert the serialized data if no sidebars
		// are added yet
		if( empty( $_POST['flocks-sidebar-name'] ) ){
			wp_safe_redirect( admin_url( 'themes.php?page='.FLOCKS_SIDEBAR_UNIQUE_ID.'&sidebar-error=true' ) );
			die();
		}

		// allow only alpha numeric
		if( preg_match('/[^a-z_\-0-9\s]/i', $_POST['flocks-sidebar-name'] ))
		{
			wp_safe_redirect( admin_url( 'themes.php?page='.FLOCKS_SIDEBAR_UNIQUE_ID.'&sidebar-error=true&type=c' ) );
			die();
		}

		$sidebar_name = esc_attr( stripslashes( $_POST['flocks-sidebar-name'] ) );
		$sidebar_id = sanitize_title( $_POST['flocks-sidebar-name'] );
		$value = array(
				$sidebar_id => array(
						'flocks-sidebar-name' => $sidebar_name,
						'flocks-sidebar-id' => $sidebar_id,
						'flocks-sidebar-description' => esc_attr( $_POST['flocks-sidebar-description'] )
					)
				);

		// check if there are no sidebars
		if( empty( $current_sidebars ) ){
			// update the option
			update_option(  $option_key, serialize( $value ) );
			wp_safe_redirect( admin_url( 'themes.php?page='.FLOCKS_SIDEBAR_UNIQUE_ID.'&sidebar-success=true' ) );
		}else{
			// if option is already set, it means there are existing sidebars
			// then, get all the sidebars first
			$existing_sidebars = unserialize( get_option( $option_key ) );

			// check if the same sidebar already exists
			if( array_key_exists( $sidebar_id , $existing_sidebars ) ){
				wp_safe_redirect( admin_url( 'themes.php?page='.FLOCKS_SIDEBAR_UNIQUE_ID.'&sidebar-error=true&type=u' ) );
			}else{
				// add new sidebar :)
				$existing_sidebars[$sidebar_id] = array(
						'flocks-sidebar-name' => $sidebar_name,
						'flocks-sidebar-id' => $sidebar_id,
						'flocks-sidebar-description' => esc_attr( $_POST['flocks-sidebar-description'] )
					);
				// update the option after appending our new
				// sidebar to existing one
				update_option(  $option_key, serialize( $existing_sidebars ) );
				wp_safe_redirect( admin_url( 'themes.php?page='.FLOCKS_SIDEBAR_UNIQUE_ID.'&sidebar-success=true' ) );
			}

		}
	}
	die();
}
?>
