<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Flocks
 */

if ( ! function_exists( 'flocks_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function flocks_posted_on() {

	$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
	}

	$category = explode( ",", get_the_category_list( $separator = "," ) );

	$posted_on_human_time = sprintf( _x( '%s ago', '%s = human-readable time difference', 'flocks' ), 
	human_time_diff( get_the_time( 'U' ), current_time( 'timestamp' ) ) ); 

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( $posted_on_human_time ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = sprintf(
		esc_html_x( '%s', 'post date', 'flocks' ),
		'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
	);

	$byline = sprintf(
		esc_html_x( 'By %s', 'post author', 'flocks' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo  '<span class="byline">' . $byline . '</span><span class="fa fa-clock-o"></span> ' . $posted_on . sprintf( esc_html__(' in %s', 'flocks'), $category[0]); // WPCS: XSS OK.

}
endif;

if ( ! function_exists( 'flocks_entry_footer' ) ) :
/**
 * Prints HTML with meta information for the categories, tags and comments.
 */
function flocks_entry_footer() {
	// Hide category and tag text for pages.
	if ( 'post' === get_post_type() ) {
		/* translators: used between list items, there is a space after the comma */
		$categories_list = get_the_category_list( esc_html__( ', ', 'flocks' ) );
		if ( $categories_list && flocks_categorized_blog() ) {
			printf( '<span class="cat-links">' . esc_html__( 'Posted in %1$s', 'flocks' ) . '</span>', $categories_list ); // WPCS: XSS OK.
		}

		/* translators: used between list items, there is a space after the comma */
		$tags_list = get_the_tag_list( '', esc_html__( ', ', 'flocks' ) );
		if ( $tags_list ) {
			printf( '<span class="tags-links">' . esc_html__( 'Tagged %1$s', 'flocks' ) . '</span>', $tags_list ); // WPCS: XSS OK.
		}
	}

	if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
		echo '<span class="comments-link">';
		comments_popup_link( esc_html__( 'Leave a comment', 'flocks' ), esc_html__( '1 Comment', 'flocks' ), esc_html__( '% Comments', 'flocks' ) );
		echo '</span>';
	}

	edit_post_link(
		sprintf(
			/* translators: %s: Name of current post */
			esc_html__( 'Edit %s', 'flocks' ),
			the_title( '<span class="screen-reader-text">"', '"</span>', false )
		),
		'<span class="edit-link">',
		'</span>'
	);
}
endif;

/**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function flocks_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'flocks_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,
			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'flocks_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so flocks_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so flocks_categorized_blog should return false.
		return false;
	}
}

/**
 * Flush out the transients used in flocks_categorized_blog.
 */
function flocks_category_transient_flusher() {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	// Like, beat it. Dig?
	delete_transient( 'flocks_categories' );
}
add_action( 'edit_category', 'flocks_category_transient_flusher' );
add_action( 'save_post',     'flocks_category_transient_flusher' );

if ( ! function_exists( 'flocks_bp_members_status' ) ) {
/**
 * Trim dash(-) and double qoute(") in the bp_get_member_latest_update.
 */
	function flocks_bp_members_status() {

		if ( ! function_exists( 'bp_get_member_latest_update' ) ) {
			return;
		}

		$member_latest_update = html_entity_decode( bp_get_member_latest_update() );

		echo str_replace( array( '-', '"' ), '', $member_latest_update );

		return;
	}

}
function flocks_user_registration_date() {

	$flocks_get_user_registered_date = get_userdata( bp_displayed_user_id() )->user_registered;

	$flocks_convert_user_registered_date = date( "M d, Y", strtotime( $flocks_get_user_registered_date ));

	return $flocks_convert_user_registered_date;

}

function flocks_get_cover_photo_src()
{
	if (!function_exists('bcp_get_cover_photo')) { return; }

	$item_id = bp_displayed_user_id();
	$item_type = 'user';
	$cover_photo_url = '';

	if (bp_is_group()) {
		$item_id = bp_get_group_id();
		$item_type = 'group';
	}

	$args = array(
		'type' => $item_type,
		'object_id'=> $item_id,
	);

	$cover_photo_url = esc_url(bcp_get_cover_photo($args));

	return $cover_photo_url;
}

function flocks_member_header() { ?>

	<div id="item-header">

        <?php
        /**
         * If the cover image feature is enabled, use a specific header
         */
        if ( bp_displayed_user_use_cover_image_header() ) :
            bp_get_template_part( 'members/single/cover-image-header' );
        else :
            bp_get_template_part( 'members/single/member-header' );
        endif;
        ?>

    </div><!-- #item-header -->

<?php }


function flocks_group_header() { ?>

	<div id="item-header">

		<?php
		/**
		 * If the cover image feature is enabled, use a specific header
		 */
		if ( bp_group_use_cover_image_header() ) :
			bp_get_template_part( 'groups/single/cover-image-header' );
		else :
			bp_get_template_part( 'groups/single/group-header' );
		endif;
		?>

	</div><!-- #item-header -->


<?php }

function flocks_site_logo( $logo_attr_id = 'site-logo-img' ) {

	$site_logo_src = get_theme_mod( 'flocks_site_logo' );

	

	$site_header_type = flocks_get_header_style();

	if ( empty( $site_logo_src ) ) {

		$site_logo_src = get_template_directory_uri() . '/logo.svg';

		if ( in_array( $site_header_type, array( 'header-style-3', 'header-style-4') ) ) {

			$site_logo_src = get_template_directory_uri() . '/logo-alternative.svg';

		}
	}

	if ( 'site-logo-img-footer' === $logo_attr_id ) {

		$site_footer_type = trim( get_theme_mod( 'flocks_footer_style', '' ) );

		if ( in_array( $site_footer_type, array('footer-style-2', 'footer-style-3') ) ) {
			$site_logo_src = get_template_directory_uri() . '/logo-alternative.svg';
		}

	}

	?>

	<a title="<?php echo esc_attr( bloginfo( 'name' ) ); ?>" href="<?php echo esc_url( site_url() ); ?>">
		<img id="<?php echo esc_attr( $logo_attr_id ); ?>" src="<?php echo esc_url( $site_logo_src ); ?>" alt="<?php echo esc_attr( bloginfo( 'name' ) ); ?>" />
	</a>
<?php }
/**
 * The cover photo for BuddyPress pages
 */
function flocks_bp_the_cover_photo() { ?>
<?php $flocks_cover_image_src = flocks_get_cover_photo_src(); ?>
<style>
#cv-cover-photo {
	<?php
	if ( ! empty ( $flocks_cover_image_src ) ) { ?>
		background-image: url('<?php echo esc_url( $flocks_cover_image_src ); ?>');
	<?php } else { ?>
		background-image: url('<?php echo esc_url( get_template_directory_uri() . '/assets/images/default-cover-image.jpg'); ?>');
	<?php }	?>
	background-repeat: no-repeat;
	background-size: cover;
	background-color: #f6f8f9;
	background-position: center center;;
}
</style>
<div id="cv-cover-photo">
	<div id="cv-cover-photo-elements" class="container">
		<div id="item-buttons" class="mg-right-15">
			<?php
				/**
				 * Fires in the member header actions section.
				 *
				 * @since 1.2.6
				 */
				do_action( 'bp_member_header_actions' );
			?>
		</div><!-- #item-buttons -->
		<?php do_action( 'bp_profile_header_meta' ); ?>
	</div>
</div>
<?php }

/**
 * The cover photo for group single.
 */
function flocks_bp_group_the_cover_photo() { ?>
<?php $flocks_bp_cover_image_src = flocks_get_cover_photo_src(); ?>
<style>
#cv-cover-photo {
	<?php
	if ( ! empty ( $flocks_bp_cover_image_src ) ) { ?>
		background-image: url('<?php echo esc_url( $flocks_bp_cover_image_src ); ?>');
	<?php } else { ?>
		background-image: url('<?php echo esc_url( get_template_directory_uri() . '/assets/images/default-cover-image.jpg'); ?>');
	<?php }	?>
	background-repeat: no-repeat;
	background-size: cover;
	background-color: #f6f8f9;
	background-position: center center;;
}
</style>
<div id="cv-cover-photo">
	<div id="cv-cover-photo-elements" class="container">
		<div id="item-buttons" class="mg-right-15">
			<?php
				/**
				 * Fires in the member header actions section.
				 *
				 * @since 1.2.6
				 */
				do_action( 'bp_group_header_actions' );
			?>
		</div><!-- #item-buttons -->
		<?php do_action( 'bp_profile_header_meta' ); ?>
	</div>
</div>
<?php }

/**
 * The cover photo for wordpress posts and taxonomies
 */
function flocks_the_cover_image() { ?>
	<?php
	$content_header = flocks_get_content_header_meta();
	$meta_header_background = $content_header['image'];
	$meta_header_sub_title = $content_header['sub_title'];
	$meta_header_background_color = $content_header['background_color'];
	$meta_header_text_color = $content_header['text_color'];
	$meta_header_size = $content_header['header_size'];
	$meta_header_alignment = $content_header['header_alignment'];
	?>

	<div id="cover-image">
		
		<div id="cover-image-wrap" class="<?php echo sanitize_html_class( $meta_header_size ); ?> <?php echo sanitize_html_class( $meta_header_alignment ); ?>">

			<div id="cover-image-inner-wrap">

				<div id="cover-image-copy">

				<div class="container-fluid">
				
						<?php if ( is_home() ) : ?>
								
								<?php if ( flocks_is_blog() ) : ?>

									<?php $blog_id = absint( get_option( 'page_for_posts' ) ); ?>

									<?php if ( ! empty ( $blog_id ) ) { ?>

										<?php $blog = get_post( $blog_id ); ?>
										
										<h1 class="entry-title">

											<?php echo wp_kses( $blog->post_title, wp_kses_allowed_html( 'post' ) ); ?>
										
										</h1>
										
										<?php if ( ! empty( $meta_header_sub_title ) ) { ?>
										<div class="heading-lead">

											 <?php echo wp_kses( $meta_header_sub_title, wp_kses_allowed_html( 'post' ) ); ?>

										 </div>

										 <?php } ?>

									<?php } else { ?>

										<h1 class="entry-title">

											<?php echo esc_attr( get_bloginfo('title') ); ?>

										</h1>

									<?php } ?>

								<?php else : ?>
									
									<h1 class="entry-title">

										<?php echo esc_attr( get_bloginfo('title') ); ?>

									</h1>

								<?php endif; ?>


						<?php endif; ?>

						<?php if ( is_singular() ): ?>

							 <?php  the_title( '<h1 class="entry-title">', '</h1>' ); ?>

							 <?php if ( ! empty( $meta_header_sub_title ) ) { ?>
								 
								 <div class="heading-lead">

									 <?php echo wp_kses( $meta_header_sub_title, wp_kses_allowed_html( 'post' ) ); ?>

								 </div>

							<?php } ?>

						<?php endif; ?>
						
						<?php if ( is_archive() ): ?>
							
							<?php the_archive_title( '<h1 class="entry-title">', '</h1>' ); ?>
							
							<?php the_archive_description( '<div class="heading-lead">', '</div>' ); ?>

						<?php endif; ?>

						<?php if ( is_404() ): ?>

							<h1 class="entry-title"><?php esc_html_e( '404', 'flocks' ); ?></h1>

							<div class="introductory-text">

								<p><?php esc_html_e( 'PAGE NOT FOUND', 'flocks' ); ?></p>

							</div>

						<?php endif; ?>

					</div><!--.container-->
				</div><!--#cover-image-copy-->
			</div>
		</div>
	</div>
<?php }

function flocks_bp_the_cover_image() { ?>
	
	<?php 

		$buddypress = buddypress();
		$flocks_cover_image_src = flocks_get_cover_photo_src(); 
		$object_id = get_queried_object_id();
	
		$meta_header_size_collection = array(
			'standard' => '280px',
			'bigger' => '320px',
			'extra-large' => '400px',
		);
		$meta_header_size = get_post_meta( $object_id, 'flocks_mb_page_header_size', true );
		$header_background = get_template_directory_uri() . '/assets/images/default-cover-image.jpg';
		$meta_header_background = get_post_meta( $object_id, 'flocks_mb_page_header_background', true );
		$meta_header_sub_title = get_post_meta( $object_id, 'flocks_mb_page_header_sub_title', true );
		$meta_header_background_color = get_post_meta( $object_id, 'flocks_mb_page_header_background_color', true );
		$meta_header_text_color = get_post_meta( $object_id, 'flocks_mb_page_header_text_color', true );

		if ( ! empty ( $meta_header_background ) ) {
			$header_background = $meta_header_background;
		}
	?>


	<style>
	#cover-image {
		background-image: url('<?php echo esc_url( $header_background ); ?>');
		background-repeat: no-repeat;
		background-size: cover;
		background-color: #f6f8f9;
		background-position: center center;;
	}

	#cover-image::after {
		<?php if ( ! empty ( $meta_header_background_color ) ) { ?>
			background: <?php echo esc_attr( $meta_header_background_color ); ?>;
		<?php } ?>
	}

	<?php if ( ! empty ( $meta_header_size ) ) { ?>
		#cover-image #cover-image-wrap {
			height: <?php echo flocks_sanity_check( $meta_header_size_collection[$meta_header_size] ); ?>;
		}
	<?php } ?>

	<?php if ( ! empty ( $meta_header_text_color ) ) { ?>
		#cover-image h1.entry-title, .heading-lead {
			color: <?php echo sanitize_hex_color( $meta_header_text_color ); ?>;
		}
	<?php } ?>

	</style>

	<div id="cover-image">
		<div id="cover-image-wrap">
			<div id="cover-image-inner-wrap">
				<div id="cover-image-copy">
					<?php
						$allowed_html = array(
						    'a' => array(
						        'href' => array(),
						        'title' => array()
						    ),
						    'br' => array(),
						    'em' => array(),
						    'strong' => array(),
						);
					?>
					<h1 class="entry-title">
						
						<?php $has_title = false; ?>

						<?php if ( bp_is_activity_directory() ): ?>
							<?php echo wp_kses( $buddypress->pages->activity->title, $allowed_html ); ?>
							<?php $has_title = true; ?>
						<?php endif; ?>

						<?php if ( bp_is_members_directory() ): ?>
							<?php echo wp_kses( $buddypress->pages->members->title, $allowed_html ); ?>
							<?php $has_title = true; ?>
						<?php endif; ?>

						<?php if ( isset( $buddypress->groups ) ): ?>
							<?php if ( 0 == $buddypress->groups->current_group && $buddypress->current_component == 'groups' ): ?>
								<?php echo wp_kses( $buddypress->pages->groups->title, $allowed_html ); ?>
								<?php $has_title = true; ?>
							<?php endif; ?>
						<?php endif; ?>

						<?php if ( ! $has_title ): ?>
							
							<?php the_title(); ?>

						<?php endif; ?>

					</h1>

					<?php if ( ! empty( $meta_header_sub_title ) ) { ?>
						<div class="heading-lead">
							<?php echo esc_html( $meta_header_sub_title ); ?>
						</div>
					<?php } ?>

				</div>
			</div>
		</div>
	</div>
<?php }
