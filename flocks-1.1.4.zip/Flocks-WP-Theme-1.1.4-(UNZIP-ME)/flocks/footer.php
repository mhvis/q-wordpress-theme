<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Flocks
 */

?>
	</div><!--container-->
	
	<?php get_template_part('components/footer/marketing'); ?>

	<?php $footer = get_theme_mod( 'flocks_footer_style', 'footer-style-1' ); ?>

	<?php if ( is_active_sidebar( 'site-footer') ) { ?>
		
		<?php get_template_part( $footer, $name = null ); ?>

	<?php } ?>

	<footer id="colophon" class="site-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<?php get_template_part( 'components/footer/site', 'info' ); ?>
				</div>
			</div>
		</div>
	</footer>
</div><!--#content-->
<?php wp_footer(); ?>
</body>
</html>
