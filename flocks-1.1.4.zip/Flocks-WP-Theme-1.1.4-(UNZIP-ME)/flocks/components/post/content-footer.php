	<footer class="entry-footer">
		<?php flocks_entry_footer(); ?>
	</footer><!-- .entry-footer -->