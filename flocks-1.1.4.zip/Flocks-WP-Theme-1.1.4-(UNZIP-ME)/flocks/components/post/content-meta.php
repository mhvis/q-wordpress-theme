		<div class="entry-meta">
			<?php flocks_posted_on(); ?>
		</div><!-- .entry-meta -->
