<?php

$args = array('echo' => false);

?>

<?php if ( ! is_user_logged_in() ) { ?>
<?php
$fb_status = get_theme_mod( 'enable_facebook_connect', 'disable' );
$gp_status = get_theme_mod( 'enable_google_connect', 'disable' );
?>	
<div class="gears-login-wrap" id="gears-login-shortcode">

	<?php if ( in_array( 'enable', array( $fb_status, $gp_status ), true ) ) { ?>
		<div class="gears-social-connect">
			<div class="gears-social-connect-heading">
				<div class="row">
					<div class="col-xs-12 col-sm-12 col-md-6">
						<h3>
							<?php esc_html_e( 'SOCIAL MEDIA LOGIN', 'flocks' ); ?>
						</h3>
					</div>
					<div class="col-xs-12 col-sm-12 col-md-6">
						<?php $register_link = wp_register( '', '', false ); ?>
						<div class="pull-right register-link">
							<?php echo sprintf( __( "Don't have an account yet? %1s", 'flocks'), $register_link ); ?>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
				<p>
					<?php esc_html_e('Sign in to our website with your favorite social media account. It is just one click away!', 'flocks'); ?>
				</p>
			</div>
			<div class="gears-social-connect-btns">
				<?php do_action( 'gears_login_form' ); ?>
			</div>
		</div><!--.gears-social-connect-->
	<?php } ?>
	<div class="gears-login-links">

		<ul>
			
			<li class="current">

				<?php esc_html_e('Sign-in', 'flocks'); ?>

			</li>
			
			<li>

				<a href="<?php echo wp_registration_url(); ?>" title="<?php esc_html_e('Create New Account','flocks'); ?>">

					<?php esc_html_e('Register', 'flocks'); ?>

				</a>

			</li>

		</ul>

	</div><!--.gears-login-links-->

	<div class="gears-login well">

		<?php echo wp_login_form( $args ); ?>

		<div id="gears-login-form-lost-password">
			<a title="<?php esc_attr_e( 'Forgot Password', 'flocks' ); ?>" id="gears-login-form-lp" class="hide" href="<?php echo esc_url( wp_lostpassword_url() ); ?>">
				<i class="fa fa-unlock-alt"></i>
				<?php echo esc_html_e( 'Forgot Password', 'flocks' ); ?>
			</a>
		</div>

	</div><!--.gears-login-->

</div><!--.gears-login-wrap-->

<div class="gears-clearfix"></div>

<?php } else { ?>

<div class="mg-bottom-15 gears-alert gears-alert-success">
	<?php $current_user = wp_get_current_user(); ?>
	<div class="row">
		<div class="col-md-1 col-xs-1">
			<?php echo get_avatar( $current_user->ID, 48); ?> 
		</div>
		<div class="col-md-11 col-xs-11">
			<?php echo sprintf( esc_html__('Hi, %s! You have logged in successfully. ', 'flocks'), esc_html( $current_user->display_name) ); ?>
		</div>
	</div>
</div>

<?php } ?>