<?php
extract(
	shortcode_atts( array(
		'title' => '',
		'price_label' => '0.00',
		'price_currency' => '$',
		'payment_type_text' => esc_html__( 'Per Month', 'flocks' ),
		'features' => '',
		'button_label' => esc_html__('Purchase', 'flocks'),
		'button_link' => '#',
		'popular' => 'false',
		'color' => 'alizarin',
		'test_param' => 'alizarin'
	), $atts )
);

if( !empty( $features ) ){

	$features = explode( ',', $features );

} else{

	$features = array();

}


$popular_class = '';

if ( 'true' == $popular ) { ?>

	<?php $popular_class = "popular"; ?>

<?php } ?>


<div class="gears-shortcode-element gears-pricing-table <?php echo esc_attr( $popular_class ); ?>">
	
	<div class="gears-pricing-table-title widget-title-wrap">

		<h3 class="pricing-title primary">

			<?php echo esc_html( $title ); ?>

		</h3>

	</div>

	<div class="gears-pricing-table-price-label">

		<h3>
			
			<span class="pricing-table-currency">
				<?php echo esc_html( $price_currency ); ?>&nbsp;
			</span>

			<?php echo esc_html( $price_label ); ?>	
			
			<span class="pricing-unit-text">
				<?php echo esc_html( $payment_type_text ); ?>
			</span>

		</h3>

	</div>

	<div class="gears-pricing-table-features">

		<?php if ( ! empty( $features ) ) { ?>

			<ul class="gears-pricing-table-features-list-wrap">

				<?php foreach ( ( array ) $features as $feature ) { ?>

					<?php $feature = trim( $feature ); ?>

					<?php if ( '!' == substr( $feature, 0, 1 ) ) { ?>
						
						<li class="gears-pricing-table-features-list feature-not-avail">

							<del><?php echo esc_html( substr( $feature, 1 ) ); ?></del>

						</li>

					<?php } else { ?>
						
						<li class="gears-pricing-table-features-list">

							<?php echo esc_html( $feature ); ?>

						</li>

					<?php } ?>

				<?php } ?>
			
			</ul>

		<?php } ?>
	</div>

	<div class="gears-pricing-table-btn">

		<a href="<?php echo esc_url( $button_link ); ?>" class="button">
			
			<?php echo esc_html( $button_label ); ?>

		</a>

	</div>

</div>