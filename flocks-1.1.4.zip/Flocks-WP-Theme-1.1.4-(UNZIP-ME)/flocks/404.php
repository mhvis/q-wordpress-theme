<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Flocks
 */

get_header(); ?>

<?php flocks_the_cover_image(); ?>

<div class="container-fluid">

<div class="row">

	<div class="col-sm-12">

		<div id="primary" class="content-area">

			<main id="main" class="site-main">

				<section class="error-404 not-found content-area hentry">

					<header class="page-header">

						<h1 class="page-title"><?php esc_html_e( '404', 'flocks' ); ?></h1>

						<h3><?php esc_html_e( 'Nothing found here', 'flocks' ); ?></h3>

						<p><?php esc_html_e( 'It looks like nothing was found at this location.', 'flocks' ); ?></p>

						<p><?php esc_html_e( 'The requested URL was not found on this server. That\'s all we know.', 'flocks' ); ?></p>

						<a class="btn not-found-btn" href="<?php echo esc_url( home_url('/') ); ?>" title="<?php esc_html_e( 'GO BACK HOME', 'flocks' ); ?>">

							<span class="fa fa-angle-left"></span>

							<?php esc_html_e( 'GO BACK HOME', 'flocks' ); ?>
							
						</a>

					</header>

					<div class="row">
						<div class="page-content">
							<?php $search_site_url = str_replace( array('http://', 'https://'),'', site_url() ); ?>
							<form method="get" class="searchform" action="<?php echo home_url( '/' ); ?>">
							    <label>
							        <label class="hidden screen-reader-text" for="s">
										<?php esc_html_e('Search for:', 'flocks'); ?>
									</label>

									<input type="search" value=""
									placeholder="<?php esc_attr_e('Search ', 'flocks'); ?> <?php echo esc_attr( $search_site_url ); ?>" 
									name="s" id="s" />

							        <button type="submit" class="searchsubmit">
							            <span class="hidden-xs"><?php esc_attr_e('Search', 'flocks'); ?></span>
							        </button>
							    </label>
							</form>
						</div>
					</div>

				</section>
			</main>
		</div>
	</div><!--col-xs-12-->
</div><!--.row-->
</div>
<?php
get_footer();
