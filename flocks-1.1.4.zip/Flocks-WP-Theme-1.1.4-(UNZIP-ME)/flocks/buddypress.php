<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Flocks
 */

get_header();

while ( have_posts() ) : the_post(); ?>

    <?php // Display cover photo for member ?>
    <?php if ( bp_is_user() ) { ?>
        <?php flocks_member_header(); ?>
    <?php } ?>

    <?php // Display cover photo for groups. ?>
    <?php if ( bp_is_groups_component() && bp_is_single_item() ) { ?>
            <?php if ( bp_has_groups() ) : while ( bp_groups() ) : bp_the_group(); ?>
                <?php flocks_group_header(); ?>
            <?php endwhile; ?>
        <?php endif; ?>
    <?php } ?>

    <?php if ( ! bp_is_group_create() ) { ?>
        <?php if ( ! bp_is_user() && ! ( bp_is_groups_component() && bp_is_single_item() ) ) { ?>
            <?php flocks_bp_the_cover_image(); ?>
        <?php } ?>
    <?php } ?>

	<div id="printable-content">
		<div class="container">
			<div class="row">
				<div class="<?php echo apply_filters( 'flocks_main_section_class', 'col-lg-9' ); ?>">
					<div id="primary" class="content-area">
						<main id="main" class="site-main">
							<?php
								get_template_part( 'components/page/content', 'page' );
							?>
						</main>
					</div>
				</div><!--.col-lg-9-->
				<div class="<?php echo apply_filters( 'flocks_sidebar_section_class', 'col-lg-3' ); ?>">
                    <?php if ( bp_is_group_single() ) { ?>
                        <!-- Custom BuddyPress Widget for Group -->
                        <section class="widget widget-flocks-bp-custom-widget">
                            <h2 class="widget-title">
                                <?php esc_attr_e('About', 'flocks'); ?>
                            </h2>
                            <div class="flocks-bp-custom-widget-group-about">

                                <h5><?php bp_group_name(); ?></h5>
                                <?php bp_group_description(); ?>
                                <hr />

                            	<p class="small">
                                    <span class="highlight">
                                    <?php bp_group_type(); ?></span><br/>
                                    <span class="activity">
                                        <?php printf( esc_html__( 'Active %s', 'flocks' ), bp_get_group_last_active() ); ?>
                                    </span>
                                    <?php if ( function_exists('bp_group_type_list') ) { ?>
                                        <?php echo bp_group_type_list(); ?>
                                    <?php } ?>
                                </p>

                            </div>
                        </section>
                    <?php } ?>
					<?php get_sidebar(); ?>
				</div><!--.col-lg-3-->
			</div><!--.row-->
		</div><!--.container-->
	</div><!--#printable-content-->

<?php
endwhile; // End of the loop.
get_footer();
