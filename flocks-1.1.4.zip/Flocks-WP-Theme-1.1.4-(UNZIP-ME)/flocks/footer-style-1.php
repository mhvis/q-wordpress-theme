<?php
/**
 * Footer Style 1 File
 *
 * @since  1.0
 */
?>
<div id="site-footer-widgets" class="footer-style-1 site-footer-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div id="widget-collections">
					<?php dynamic_sidebar('site-footer'); ?>
				</div>
			</div>
		</div>
	</div>
</div>